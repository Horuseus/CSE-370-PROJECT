<?php
$pageTitle = 'Donate – SAFR';
require_once __DIR__ . '/../config/db.php';
if (session_status() === PHP_SESSION_NONE) session_start();
$conn = getDBConnection();
$msg = ''; $err = '';

// Process donation
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['donate'])) {
    $name    = $conn->real_escape_string(trim($_POST['donor_name'] ?? ''));
    $phone   = $conn->real_escape_string(trim($_POST['phone'] ?? ''));
    $email   = $conn->real_escape_string(trim($_POST['email'] ?? ''));
    $amount  = (float)($_POST['amount'] ?? 0);
    $method  = $conn->real_escape_string($_POST['payment_method'] ?? '');
    $dtype   = $conn->real_escape_string($_POST['donation_type'] ?? 'one-time');
    $donor_t = $conn->real_escape_string($_POST['donor_type'] ?? 'one-time');
    $ngo     = $conn->real_escape_string($_POST['ngo_name'] ?? '');

    if ($amount <= 0) {
        $err = 'Please enter a valid donation amount.';
    } elseif (!$name) {
        $err = 'Please enter your name.';
    } else {
        // Upsert Donor record, accumulate total
        $existing = $conn->query("SELECT Name, Total_Amount FROM Donor WHERE Name='$name'");
        if ($existing && $existing->num_rows > 0) {
            $old = $existing->fetch_assoc()['Total_Amount'];
            $new_total = $old + $amount;
            $conn->query("UPDATE Donor SET Total_Amount=$new_total, Payment_Method='$method',
                          Donation_type='$dtype', Donor_type='$donor_t', Email='$email', Phone='$phone'
                          WHERE Name='$name'");
        } else {
            $conn->query("INSERT INTO Donor (Name,Phone,Email,Payment_Method,Total_Amount,Donation_type,Donor_type)
                          VALUES ('$name','$phone','$email','$method',$amount,'$dtype','$donor_t')");
            // Create credential if signed up
            if (isset($_SESSION['user']) && $_SESSION['user']['role'] === 'donor') {
                // credential already exists
            }
        }
        // Link to NGO if selected
        if ($ngo) {
            // Ensure donor credential exists in donor_ngo
            $conn->query("INSERT IGNORE INTO Donor_NGO (NGO_name,Donor_Name) VALUES ('$ngo','$name')");
        }
        $msg = "Thank you, <strong>$name</strong>! Your donation of <strong>$" . number_format($amount,2) . "</strong> has been recorded.";
    }
}

// Fetch NGOs for dropdown
$ngos = [];
$qn = $conn->query("SELECT NGO_name FROM NGO ORDER BY NGO_name");
while ($row = $qn->fetch_assoc()) $ngos[] = $row;

// Top donors
$top_donors = [];
$qd = $conn->query("SELECT Name, Total_Amount, Donor_type FROM Donor ORDER BY Total_Amount DESC LIMIT 10");
while ($row = $qd->fetch_assoc()) $top_donors[] = $row;

// Total raised
$total_raised = $conn->query("SELECT SUM(Total_Amount) AS t FROM Donor")->fetch_assoc()['t'] ?? 0;
$donor_count  = $conn->query("SELECT COUNT(*) AS c FROM Donor")->fetch_assoc()['c'] ?? 0;

$conn->close();
include __DIR__ . '/../includes/header.php';
?>
<div class="page-header">
  <div class="container">
    <div class="hero-badge" style="margin-bottom:.75rem;">Module 07</div>
    <h1>Donations & Support</h1>
    <p>Every contribution — large or small — directly funds camp operations, medical care, food, and transport for refugees.</p>
  </div>
</div>

<div class="section">
  <div class="container">

    <!-- Stats -->
    <div class="stat-grid fade-up" style="margin-bottom:2.5rem;">
      <div class="stat-card">
        <div class="stat-icon amber">💰</div>
        <div><div class="stat-value">$<span data-count="<?= number_format($total_raised,0,'.','') ?>">0</span></div><div class="stat-label">Total Raised</div></div>
      </div>
      <div class="stat-card">
        <div class="stat-icon gold">🤲</div>
        <div><div class="stat-value" data-count="<?= $donor_count ?>">0</div><div class="stat-label">Donors Worldwide</div></div>
      </div>
      <div class="stat-card">
        <div class="stat-icon brown">100%</div>
        <div><div class="stat-value">100%</div><div class="stat-label">Goes to Camps</div></div>
      </div>
    </div>

    <div style="display:grid;grid-template-columns:1fr 380px;gap:2rem;align-items:start;" class="donate-grid">

      <!-- Donation Form -->
      <div class="fade-up">
        <?php if ($err):  ?><div class="alert alert-error"><?= $err ?></div><?php endif; ?>
        <?php if ($msg):  ?><div class="alert alert-success"><?= $msg ?></div><?php endif; ?>

        <div class="card card-body">
          <h3 style="margin-bottom:.5rem;color:var(--brown-dark);">Make a Donation</h3>
          <p style="font-size:.875rem;color:var(--brown);margin-bottom:1.5rem;">Choose any amount. Set up as a regular donor to give monthly.</p>

          <!-- Quick amount buttons -->
          <div style="display:flex;gap:.5rem;flex-wrap:wrap;margin-bottom:1.5rem;" id="quick-amounts">
            <button type="button" class="btn btn-ghost btn-sm quick-amt" data-amount="10">$10</button>
            <button type="button" class="btn btn-ghost btn-sm quick-amt" data-amount="25">$25</button>
            <button type="button" class="btn btn-ghost btn-sm quick-amt" data-amount="50">$50</button>
            <button type="button" class="btn btn-ghost btn-sm quick-amt" data-amount="100">$100</button>
            <button type="button" class="btn btn-ghost btn-sm quick-amt" data-amount="250">$250</button>
          </div>

          <form method="POST">
            <div class="form-row">
              <div class="form-group">
                <label class="form-label">Your Full Name</label>
                <input type="text" name="donor_name" id="donor-name" class="form-control" placeholder="Full name"
                  value="<?= htmlspecialchars(isset($_SESSION['user']) && $_SESSION['user']['role']==='donor' ? $_SESSION['user']['name'] : '') ?>" required>
              </div>
              <div class="form-group">
                <label class="form-label">Donation Amount (USD)</label>
                <input type="number" name="amount" id="donation-amount" class="form-control" placeholder="e.g. 50" min="1" step="0.01" required>
              </div>
            </div>
            <div class="form-row">
              <div class="form-group">
                <label class="form-label">Email</label>
                <input type="email" name="email" class="form-control" placeholder="Your email">
              </div>
              <div class="form-group">
                <label class="form-label">Phone (optional)</label>
                <input type="text" name="phone" class="form-control" placeholder="Phone number">
              </div>
            </div>
            <div class="form-row">
              <div class="form-group">
                <label class="form-label">Donor Type</label>
                <select name="donor_type" class="form-control">
                  <option value="one-time">One-time Donor</option>
                  <option value="regular">Regular / Monthly Donor</option>
                </select>
              </div>
              <div class="form-group">
                <label class="form-label">Donation Type</label>
                <select name="donation_type" class="form-control">
                  <option value="general">General Fund</option>
                  <option value="medical">Medical Aid</option>
                  <option value="food">Food & Water</option>
                  <option value="shelter">Shelter</option>
                  <option value="transport">Transport / Evacuation</option>
                </select>
              </div>
            </div>
            <div class="form-row">
              <div class="form-group">
                <label class="form-label">Payment Method</label>
                <select name="payment_method" class="form-control">
                  <option>Credit Card</option>
                  <option>Debit Card</option>
                  <option>Bank Transfer</option>
                  <option>PayPal</option>
                  <option>Mobile Money</option>
                </select>
              </div>
              <div class="form-group">
                <label class="form-label">Direct to NGO (optional)</label>
                <select name="ngo_name" class="form-control">
                  <option value="">General SAFR Fund</option>
                  <?php foreach ($ngos as $n): ?>
                    <option value="<?= htmlspecialchars($n['NGO_name']) ?>"><?= htmlspecialchars($n['NGO_name']) ?></option>
                  <?php endforeach; ?>
                </select>
              </div>
            </div>
            <button type="submit" name="donate" class="btn btn-primary btn-block btn-lg" style="margin-top:.5rem;">Donate Now</button>
            <p style="font-size:.78rem;color:var(--brown);text-align:center;margin-top:.75rem;">
              Your donation is recorded securely. 100% goes to humanitarian operations.
            </p>
          </form>
        </div>
      </div>

      <!-- Sidebar: Impact + Top Donors -->
      <div style="display:flex;flex-direction:column;gap:1.5rem;" class="fade-up">
        <div class="card card-body" style="background:linear-gradient(135deg,var(--brown-dark),var(--brown));color:var(--cream);">
          <h3 style="color:var(--gold-light);margin-bottom:1rem;">Your Impact</h3>
          <ul style="list-style:none;display:flex;flex-direction:column;gap:.75rem;font-size:.875rem;">
            <li><strong>$10</strong> feeds a family for one day</li>
            <li><strong>$25</strong> covers basic medical supplies</li>
            <li><strong>$50</strong> provides shelter for a week</li>
            <li><strong>$100</strong> funds part of an evacuation trip</li>
            <li><strong>$250</strong> helps run a camp for a day</li>
          </ul>
        </div>

        <div class="card card-body">
          <h3 style="margin-bottom:1rem;color:var(--brown-dark);">Top Donors</h3>
          <?php if (empty($top_donors)): ?>
            <p style="font-size:.875rem;color:var(--brown);">Be the first to donate!</p>
          <?php else: ?>
            <ul style="list-style:none;display:flex;flex-direction:column;gap:.6rem;">
              <?php foreach ($top_donors as $i => $d): ?>
              <li style="display:flex;align-items:center;gap:.75rem;">
                <span style="width:24px;height:24px;border-radius:50%;background:linear-gradient(135deg,var(--amber),var(--gold));display:grid;place-items:center;font-size:.7rem;font-weight:700;color:var(--brown-dark);flex-shrink:0;"><?= $i+1 ?></span>
                <span style="flex:1;font-size:.875rem;color:var(--brown-dark);"><?= htmlspecialchars($d['Name']) ?></span>
                <span style="font-weight:700;color:var(--brown-mid);">$<?= number_format($d['Total_Amount'],2) ?></span>
                <span class="badge <?= $d['Donor_type']==='regular'?'badge-green':'badge-amber' ?>"><?= ucfirst($d['Donor_type']) ?></span>
              </li>
              <?php endforeach; ?>
            </ul>
          <?php endif; ?>
        </div>
      </div>
    </div>
  </div>
</div>

<style>
  .donate-grid { grid-template-columns: 1fr 380px; }
  @media(max-width:900px) { .donate-grid { grid-template-columns: 1fr !important; } }
  .quick-amt.selected { background: var(--amber); color: var(--white); border-color: var(--amber); }
</style>
<script>
document.querySelectorAll('.quick-amt').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.quick-amt').forEach(b => b.classList.remove('selected'));
    btn.classList.add('selected');
    document.getElementById('donation-amount').value = btn.dataset.amount;
  });
});
</script>
<?php include __DIR__ . '/../includes/footer.php'; ?>
