<?php
$pageTitle = 'Aid Distribution – SAFR';
require_once __DIR__ . '/../config/db.php';
if (session_status() === PHP_SESSION_NONE) session_start();
$conn = getDBConnection();
$msg = '';

// Submit camp request to NGO
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_request'])) {
    $camp_id = $conn->real_escape_string($_POST['camp_id'] ?? '');
    $ngo     = $conn->real_escape_string($_POST['ngo_name'] ?? '');
    $item    = $conn->real_escape_string($_POST['item_requested'] ?? '');
    $qty     = (int)($_POST['item_quantity'] ?? 0);
    $r = $conn->query("INSERT INTO Camp_Request (Camp_id,NGO_name,Item_Requested,Item_quantity)
                       VALUES ('$camp_id','$ngo','$item',$qty)
                       ON DUPLICATE KEY UPDATE Item_Requested='$item', Item_quantity=$qty");
    $msg = $r ? 'Aid request submitted to NGO.' : 'Error: ' . $conn->error;
}

// Add aid item by NGO
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_aid'])) {
    $item    = $conn->real_escape_string($_POST['item_name'] ?? '');
    $cat     = $conn->real_escape_string($_POST['category'] ?? '');
    $unit    = (int)($_POST['unit'] ?? 0);
    $camp_id = $conn->real_escape_string($_POST['camp_id'] ?? '');
    $ngo     = $conn->real_escape_string($_POST['ngo_name'] ?? '');
    $r = $conn->query("INSERT INTO Aid (Item_name,Category,Unit,Camp_id,NGO_name)
                       VALUES ('$item','$cat',$unit,'$camp_id','$ngo')
                       ON DUPLICATE KEY UPDATE Unit=$unit, Category='$cat'");
    $msg = $r ? 'Aid item recorded.' : 'Error: ' . $conn->error;
}

// Fetch camp requests
$requests = [];
$q = $conn->query("SELECT cr.*, c.Location FROM Camp_Request cr LEFT JOIN Camp c ON cr.Camp_id=c.Camp_id ORDER BY cr.Camp_id");
while ($row = $q->fetch_assoc()) $requests[] = $row;

// Fetch aid items
$aid_items = [];
$qa = $conn->query("SELECT a.*, c.Location FROM Aid a LEFT JOIN Camp c ON a.Camp_id=c.Camp_id ORDER BY a.Camp_id");
while ($row = $qa->fetch_assoc()) $aid_items[] = $row;

// Camps & NGOs
$camps = []; $ngos = [];
$qc = $conn->query("SELECT Camp_id, Location FROM Camp");
while ($row = $qc->fetch_assoc()) $camps[] = $row;
$qn = $conn->query("SELECT NGO_name FROM NGO");
while ($row = $qn->fetch_assoc()) $ngos[] = $row;

$conn->close();
include __DIR__ . '/../includes/header.php';
?>
<div class="page-header">
  <div class="container">
    <div class="hero-badge" style="margin-bottom:.75rem;">Module 04</div>
    <h1>Humanitarian Aid Distribution</h1>
    <p>NGOs monitor camp needs and streamline aid delivery so every camp gets what it needs in time.</p>
  </div>
</div>

<div class="section">
  <div class="container">
    <?php if ($msg): ?><div class="alert alert-success" data-auto-dismiss><?= htmlspecialchars($msg) ?></div><?php endif; ?>

    <div class="tab-container" data-tabs>
      <div class="tabs">
        <button class="tab-btn active" data-tab="tab-aid-overview">📊 Aid Overview</button>
        <button class="tab-btn" data-tab="tab-camp-request">Camp Requests</button>
        <button class="tab-btn" data-tab="tab-add-aid">➕ Record Aid</button>
        <button class="tab-btn" data-tab="tab-make-request">📨 Request Aid</button>
      </div>

      <!-- Overview -->
      <div class="tab-panel active" id="tab-aid-overview">
        <div class="table-wrapper">
          <table class="safr-table">
            <thead><tr><th>Item</th><th>Category</th><th>Units</th><th>Camp</th><th>Location</th><th>NGO</th></tr></thead>
            <tbody>
              <?php if (empty($aid_items)): ?>
                <tr><td colspan="6" style="text-align:center;padding:2rem;">No aid items recorded yet.</td></tr>
              <?php else: ?>
                <?php foreach ($aid_items as $a): ?>
                <tr>
                  <td><strong><?= htmlspecialchars($a['Item_name']) ?></strong></td>
                  <td><span class="badge badge-gold"><?= htmlspecialchars($a['Category'] ?? '—') ?></span></td>
                  <td><?= $a['Unit'] ?></td>
                  <td><?= htmlspecialchars($a['Camp_id']) ?></td>
                  <td><?= htmlspecialchars($a['Location'] ?? '—') ?></td>
                  <td><?= htmlspecialchars($a['NGO_name']) ?></td>
                </tr>
                <?php endforeach; ?>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>

      <!-- Camp Requests -->
      <div class="tab-panel" id="tab-camp-request">
        <div class="table-wrapper">
          <table class="safr-table">
            <thead><tr><th>Camp ID</th><th>Location</th><th>NGO</th><th>Item Requested</th><th>Quantity</th></tr></thead>
            <tbody>
              <?php if (empty($requests)): ?>
                <tr><td colspan="5" style="text-align:center;padding:2rem;">No requests submitted yet.</td></tr>
              <?php else: ?>
                <?php foreach ($requests as $req): ?>
                <tr>
                  <td><?= htmlspecialchars($req['Camp_id']) ?></td>
                  <td><?= htmlspecialchars($req['Location'] ?? '—') ?></td>
                  <td><?= htmlspecialchars($req['NGO_name']) ?></td>
                  <td><?= htmlspecialchars($req['Item_Requested']) ?></td>
                  <td><strong><?= $req['Item_quantity'] ?></strong></td>
                </tr>
                <?php endforeach; ?>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>

      <!-- Add Aid (NGO) -->
      <div class="tab-panel" id="tab-add-aid">
        <div class="card card-body" style="max-width:600px;">
          <h3 style="margin-bottom:1.25rem;">Record Aid Item Dispatched</h3>
          <form method="POST">
            <div class="form-row">
              <div class="form-group">
                <label class="form-label">Item Name</label>
                <input type="text" name="item_name" class="form-control" placeholder="e.g. Blankets" required>
              </div>
              <div class="form-group">
                <label class="form-label">Category</label>
                <select name="category" class="form-control">
                  <option>Food</option><option>Medicine</option><option>Clothing</option>
                  <option>Shelter</option><option>Hygiene</option><option>Other</option>
                </select>
              </div>
            </div>
            <div class="form-row">
              <div class="form-group">
                <label class="form-label">Units</label>
                <input type="number" name="unit" class="form-control" placeholder="Quantity" min="1" required>
              </div>
              <div class="form-group">
                <label class="form-label">Destination Camp</label>
                <select name="camp_id" class="form-control" required>
                  <option value="">Select Camp</option>
                  <?php foreach ($camps as $c): ?><option value="<?= htmlspecialchars($c['Camp_id']) ?>"><?= htmlspecialchars($c['Camp_id'].' – '.$c['Location']) ?></option><?php endforeach; ?>
                </select>
              </div>
            </div>
            <div class="form-group">
              <label class="form-label">NGO Name</label>
              <select name="ngo_name" class="form-control" required>
                <option value="">Select NGO</option>
                <?php foreach ($ngos as $n): ?><option value="<?= htmlspecialchars($n['NGO_name']) ?>"><?= htmlspecialchars($n['NGO_name']) ?></option><?php endforeach; ?>
              </select>
            </div>
            <button type="submit" name="add_aid" class="btn btn-primary">Record Aid Item</button>
          </form>
        </div>
      </div>

      <!-- Make Request -->
      <div class="tab-panel" id="tab-make-request">
        <div class="card card-body" style="max-width:600px;">
          <h3 style="margin-bottom:1.25rem;">Camp: Request Aid from NGO</h3>
          <form method="POST">
            <div class="form-row">
              <div class="form-group">
                <label class="form-label">Camp</label>
                <select name="camp_id" class="form-control" required>
                  <option value="">Select Camp</option>
                  <?php foreach ($camps as $c): ?><option value="<?= htmlspecialchars($c['Camp_id']) ?>"><?= htmlspecialchars($c['Camp_id'].' – '.$c['Location']) ?></option><?php endforeach; ?>
                </select>
              </div>
              <div class="form-group">
                <label class="form-label">NGO to Request From</label>
                <select name="ngo_name" class="form-control" required>
                  <option value="">Select NGO</option>
                  <?php foreach ($ngos as $n): ?><option value="<?= htmlspecialchars($n['NGO_name']) ?>"><?= htmlspecialchars($n['NGO_name']) ?></option><?php endforeach; ?>
                </select>
              </div>
            </div>
            <div class="form-row">
              <div class="form-group">
                <label class="form-label">Item Requested</label>
                <input type="text" name="item_requested" class="form-control" placeholder="What do you need?" required>
              </div>
              <div class="form-group">
                <label class="form-label">Quantity</label>
                <input type="number" name="item_quantity" class="form-control" placeholder="How many?" min="1" required>
              </div>
            </div>
            <button type="submit" name="submit_request" class="btn btn-primary">Submit Request</button>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
