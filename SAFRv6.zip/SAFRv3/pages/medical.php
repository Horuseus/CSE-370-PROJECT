<?php
$pageTitle = 'Medical Resources – SAFR';
require_once __DIR__ . '/../config/db.php';
if (session_status() === PHP_SESSION_NONE) session_start();
$conn = getDBConnection();
$msg = ''; $err = '';

// Add item to inventory
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_item'])) {
    $inv_id   = $conn->real_escape_string($_POST['inventory_id'] ?? '');
    $item     = $conn->real_escape_string($_POST['item_name'] ?? '');
    $camp_id  = $conn->real_escape_string($_POST['camp_id'] ?? '');
    $qty      = (int)($_POST['quantity'] ?? 0);
    $today    = date('Y-m-d');
    // Insert into Camp_Medical_Inventory
    $r1 = $conn->query("INSERT IGNORE INTO Camp_Medical_Inventory (Inventory_id,Item_name,Camp_id) VALUES ('$inv_id','$item','$camp_id')");
    // Upsert amount
    $conn->query("INSERT INTO ITEM_amount (Inventory_id,Item_name,Quantity) VALUES ('$inv_id','$item',$qty)
                  ON DUPLICATE KEY UPDATE Quantity=$qty");
    $conn->query("INSERT INTO Inventory_update (Inventory_id,Item_name,Last_updated) VALUES ('$inv_id','$item','$today')
                  ON DUPLICATE KEY UPDATE Last_updated='$today'");
    $msg = $r1 ? 'Item added/updated successfully.' : 'Error: ' . $conn->error;
}

// Request medical supply from another camp
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['request_supply'])) {
    $req_inv  = $conn->real_escape_string($_POST['req_inv_id'] ?? '');
    $tgt_inv  = $conn->real_escape_string($_POST['tgt_inv_id'] ?? '');
    $item_need= $conn->real_escape_string($_POST['item_needed'] ?? '');
    $units    = (int)($_POST['units'] ?? 0);
    $r = $conn->query("INSERT IGNORE INTO Camp_Medical_Inventory_Asks_For
                       (Requesting_Inventory_id,Requested_Inventory_id,Item_needed,Units,Status)
                       VALUES ('$req_inv','$tgt_inv','$item_need',$units,0)");
    $msg = $r ? 'Supply request submitted.' : 'Error: ' . $conn->error;
}

// Fetch inventory with amounts
$inventory = [];
$q = $conn->query("SELECT i.Inventory_id, i.Item_name, i.Camp_id,
    a.Quantity, u.Last_updated
    FROM Camp_Medical_Inventory i
    LEFT JOIN ITEM_amount a ON i.Inventory_id=a.Inventory_id AND i.Item_name=a.Item_name
    LEFT JOIN Inventory_update u ON i.Inventory_id=u.Inventory_id AND i.Item_name=u.Item_name
    ORDER BY u.Last_updated DESC LIMIT 100");
while ($row = $q->fetch_assoc()) $inventory[] = $row;

// Pending requests
$requests = [];
$q2 = $conn->query("SELECT * FROM Camp_Medical_Inventory_Asks_For WHERE Status=0 LIMIT 30");
while ($row = $q2->fetch_assoc()) $requests[] = $row;

// Camps for dropdowns
$camps = [];
$qc = $conn->query("SELECT Camp_id, Location FROM Camp ORDER BY Location");
while ($row = $qc->fetch_assoc()) $camps[] = $row;

$conn->close();
include __DIR__ . '/../includes/header.php';
?>
<div class="page-header">
  <div class="container">
    <div class="hero-badge" style="margin-bottom:.75rem;">Module 02</div>
    <h1>Medical Resource Management</h1>
    <p>Track, share, and request medical supplies between camps in real time.</p>
  </div>
</div>

<div class="section">
  <div class="container">
    <?php if ($msg): ?><div class="alert alert-success" data-auto-dismiss><?= htmlspecialchars($msg) ?></div><?php endif; ?>

    <div class="tab-container" data-tabs>
      <div class="tabs">
        <button class="tab-btn active" data-tab="tab-inventory">📋 Inventory</button>
        <button class="tab-btn" data-tab="tab-add">➕ Add / Update Item</button>
        <button class="tab-btn" data-tab="tab-request">🔄 Request Supply</button>
        <button class="tab-btn" data-tab="tab-pending">⏳ Pending Requests</button>
      </div>

      <!-- Inventory Table -->
      <div class="tab-panel active" id="tab-inventory">
        <div class="table-wrapper">
          <table class="safr-table">
            <thead><tr><th>Inventory ID</th><th>Item Name</th><th>Camp ID</th><th>Quantity</th><th>Status</th><th>Last Updated</th></tr></thead>
            <tbody>
              <?php if (empty($inventory)): ?>
                <tr><td colspan="6" style="text-align:center;padding:2rem;">No inventory data yet.</td></tr>
              <?php else: ?>
                <?php foreach ($inventory as $item): ?>
                <tr>
                  <td><?= htmlspecialchars($item['Inventory_id']) ?></td>
                  <td><?= htmlspecialchars($item['Item_name']) ?></td>
                  <td><span class="badge badge-gray"><?= htmlspecialchars($item['Camp_id'] ?? '—') ?></span></td>
                  <td><strong><?= $item['Quantity'] ?? 0 ?></strong></td>
                  <td>
                    <?php $qty = $item['Quantity'] ?? 0;
                    if ($qty == 0)      echo '<span class="badge badge-red">Out of Stock</span>';
                    elseif ($qty < 10)  echo '<span class="badge badge-amber">Low Stock</span>';
                    else                echo '<span class="badge badge-green">In Stock</span>'; ?>
                  </td>
                  <td><?= htmlspecialchars($item['Last_updated'] ?? '—') ?></td>
                </tr>
                <?php endforeach; ?>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>

      <!-- Add Item -->
      <div class="tab-panel" id="tab-add">
        <div class="card card-body">
          <h3 style="margin-bottom:1.25rem;">Add / Update Inventory Item</h3>
          <form method="POST">
            <div class="form-row">
              <div class="form-group">
                <label class="form-label">Inventory ID</label>
                <input type="text" name="inventory_id" class="form-control" placeholder="e.g. INV-CAMP1" required>
              </div>
              <div class="form-group">
                <label class="form-label">Camp</label>
                <select name="camp_id" class="form-control" required>
                  <option value="">Select Camp</option>
                  <?php foreach ($camps as $c): ?>
                    <option value="<?= htmlspecialchars($c['Camp_id']) ?>"><?= htmlspecialchars($c['Camp_id'].' – '.$c['Location']) ?></option>
                  <?php endforeach; ?>
                </select>
              </div>
            </div>
            <div class="form-row">
              <div class="form-group">
                <label class="form-label">Item Name</label>
                <input type="text" name="item_name" class="form-control" placeholder="e.g. Morphine 10mg" required>
              </div>
              <div class="form-group">
                <label class="form-label">Quantity</label>
                <input type="number" name="quantity" class="form-control" placeholder="Units available" min="0" required>
              </div>
            </div>
            <button type="submit" name="add_item" class="btn btn-primary">Save Item</button>
          </form>
        </div>
      </div>

      <!-- Request Supply -->
      <div class="tab-panel" id="tab-request">
        <div class="card card-body">
          <h3 style="margin-bottom:1.25rem;">Request Emergency Supply from Another Camp</h3>
          <form method="POST">
            <div class="form-row">
              <div class="form-group">
                <label class="form-label">Your Inventory ID</label>
                <input type="text" name="req_inv_id" class="form-control" placeholder="Your inventory ID" required>
              </div>
              <div class="form-group">
                <label class="form-label">Target Inventory ID (other camp)</label>
                <input type="text" name="tgt_inv_id" class="form-control" placeholder="Their inventory ID" required>
              </div>
            </div>
            <div class="form-row">
              <div class="form-group">
                <label class="form-label">Item Needed</label>
                <input type="text" name="item_needed" class="form-control" placeholder="Item name" required>
              </div>
              <div class="form-group">
                <label class="form-label">Units Needed</label>
                <input type="number" name="units" class="form-control" placeholder="Quantity" min="1" required>
              </div>
            </div>
            <button type="submit" name="request_supply" class="btn btn-primary">Submit Request</button>
          </form>
        </div>
      </div>

      <!-- Pending Requests -->
      <div class="tab-panel" id="tab-pending">
        <div class="table-wrapper">
          <table class="safr-table">
            <thead><tr><th>Requesting Camp</th><th>From Camp</th><th>Item Needed</th><th>Units</th><th>Status</th></tr></thead>
            <tbody>
              <?php if (empty($requests)): ?>
                <tr><td colspan="5" style="text-align:center;padding:2rem;">No pending requests.</td></tr>
              <?php else: ?>
                <?php foreach ($requests as $req): ?>
                <tr>
                  <td><?= htmlspecialchars($req['Requesting_Inventory_id']) ?></td>
                  <td><?= htmlspecialchars($req['Requested_Inventory_id']) ?></td>
                  <td><?= htmlspecialchars($req['Item_needed']) ?></td>
                  <td><?= $req['Units'] ?></td>
                  <td><span class="badge badge-amber">Pending</span></td>
                </tr>
                <?php endforeach; ?>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
