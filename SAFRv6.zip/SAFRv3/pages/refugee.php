<?php
$pageTitle = 'Refugee Tracking – SAFR';
require_once __DIR__ . '/../config/db.php';
if (session_status() === PHP_SESSION_NONE) session_start();
$conn = getDBConnection();
$msg = '';

// Add identity document
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_doc'])) {
    $sid  = $conn->real_escape_string($_POST['safr_id'] ?? '');
    $dnum = $conn->real_escape_string($_POST['doc_number'] ?? '');
    $dtype= $conn->real_escape_string($_POST['doc_type'] ?? '');
    $r = $conn->query("INSERT IGNORE INTO Identity_Doc (Safr_id,Doc_number,Doc_type) VALUES ('$sid','$dnum','$dtype')");
    $msg = $r ? 'Document added successfully.' : 'Error: ' . $conn->error;
}

// Search refugees
$search = $conn->real_escape_string($_GET['search'] ?? '');
$refugees = [];
if ($search) {
    $q = $conn->query("SELECT r.*, m.Camp_location
        FROM Refugee r LEFT JOIN Match_details m ON r.Safr_id=m.Safr_id
        WHERE r.Full_name LIKE '%$search%' OR r.Safr_id LIKE '%$search%' OR r.Country LIKE '%$search%'
        LIMIT 50");
    while ($row = $q->fetch_assoc()) $refugees[] = $row;
} else {
    $q = $conn->query("SELECT r.*, m.Camp_location
        FROM Refugee r LEFT JOIN Match_details m ON r.Safr_id=m.Safr_id
        ORDER BY r.Reg_date DESC LIMIT 50");
    while ($row = $q->fetch_assoc()) $refugees[] = $row;
}

// Count
$total = $conn->query("SELECT COUNT(*) AS c FROM Refugee")->fetch_assoc()['c'];
$conn->close();
include __DIR__ . '/../includes/header.php';
?>
<div class="page-header">
  <div class="container">
    <div class="hero-badge" style="margin-bottom:.75rem;">Module 01</div>
    <h1>Refugee & Displacement Tracking</h1>
    <p>Track refugee movements, issue SAFR IDs, and manage identity documents across borders.</p>
  </div>
</div>

<div class="section">
  <div class="container">
    <?php if ($msg): ?><div class="alert alert-success" data-auto-dismiss><?= htmlspecialchars($msg) ?></div><?php endif; ?>

    <!-- Stats -->
    <div class="stat-grid fade-up" style="margin-bottom:2rem;">
      <div class="stat-card"><div class="stat-icon amber">👤</div><div><div class="stat-value"><?= number_format($total) ?></div><div class="stat-label">Registered Refugees</div></div></div>
      <div class="stat-card"><div class="stat-icon gold">🌍</div><div><div class="stat-value"><?= count($refugees) ?></div><div class="stat-label">Showing Now</div></div></div>
    </div>

    <!-- Search -->
    <div class="card card-body fade-up" style="margin-bottom:2rem;">
      <form method="GET" style="display:flex;gap:1rem;flex-wrap:wrap;align-items:flex-end;">
        <div class="form-group" style="flex:1;min-width:220px;margin:0;">
          <label class="form-label">Search by Name, SAFR ID, or Country</label>
          <input type="text" name="search" class="form-control" placeholder="e.g. Ahmad, SAFR-001-..." value="<?= htmlspecialchars($_GET['search'] ?? '') ?>">
        </div>
        <button type="submit" class="btn btn-primary">Search</button>
        <?php if ($search): ?><a href="<?= $basePath ?>/pages/refugee.php" class="btn btn-outline">Clear</a><?php endif; ?>
      </form>
    </div>

    <!-- Table -->
    <div class="table-wrapper fade-up" style="margin-bottom:2rem;">
      <table class="safr-table">
        <thead><tr><th>SAFR ID</th><th>Full Name</th><th>Country</th><th>City</th><th>Blood</th><th>Camp Location</th><th>Reg. Date</th></tr></thead>
        <tbody>
          <?php if (empty($refugees)): ?>
            <tr><td colspan="7" style="text-align:center;padding:2rem;color:var(--brown);">No records found.</td></tr>
          <?php else: ?>
            <?php foreach ($refugees as $r): ?>
            <tr>
              <td><span class="badge badge-amber"><?= htmlspecialchars($r['Safr_id']) ?></span></td>
              <td><?= htmlspecialchars($r['Full_name']) ?></td>
              <td><?= htmlspecialchars($r['Country'] ?? '—') ?></td>
              <td><?= htmlspecialchars($r['City'] ?? '—') ?></td>
              <td><?= htmlspecialchars($r['Blood_Group'] ?? '—') ?></td>
              <td><?= htmlspecialchars($r['Camp_location'] ?? '—') ?></td>
              <td><?= htmlspecialchars($r['Reg_date'] ?? '—') ?></td>
            </tr>
            <?php endforeach; ?>
          <?php endif; ?>
        </tbody>
      </table>
    </div>

    <!-- Add Identity Doc -->
    <?php if (isset($_SESSION['user'])): ?>
    <div class="card card-body fade-up">
      <h3 style="margin-bottom:1.25rem;color:var(--brown-dark);">Add Identity Document</h3>
      <form method="POST">
        <div class="form-row">
          <div class="form-group">
            <label class="form-label">SAFR ID</label>
            <input type="text" name="safr_id" class="form-control" placeholder="SAFR-XXX-..." required
              value="<?= htmlspecialchars($_SESSION['user']['safr_id'] ?? '') ?>">
          </div>
          <div class="form-group">
            <label class="form-label">Document Type</label>
            <select name="doc_type" class="form-control">
              <option>Passport</option>
              <option>Driving License</option>
              <option>National ID</option>
              <option>Birth Certificate</option>
              <option>Other</option>
            </select>
          </div>
          <div class="form-group">
            <label class="form-label">Document Number</label>
            <input type="text" name="doc_number" class="form-control" placeholder="Document number" required>
          </div>
        </div>
        <button type="submit" name="add_doc" class="btn btn-primary">Add Document</button>
      </form>
    </div>
    <?php endif; ?>
  </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
