<?php
$pageTitle = 'Evacuation – SAFR';
require_once __DIR__ . '/../config/db.php';
if (session_status() === PHP_SESSION_NONE) session_start();
$conn = getDBConnection();
$msg = '';

// Submit evacuation request
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['request_evac'])) {
    $safr_id  = $conn->real_escape_string($_POST['safr_id'] ?? '');
    $priority = $conn->real_escape_string($_POST['priority'] ?? 'medium');
    $area     = $conn->real_escape_string($_POST['area'] ?? '');
    $evareq_id= 'EVA-'.strtoupper(substr(md5(uniqid()),0,8));
    $today    = date('Y-m-d');
    $r = $conn->query("INSERT INTO Evac_Request (Evareq_id,Status,Priority,Request_date,Safr_id,Operating_areas)
                       VALUES ('$evareq_id',0,'$priority','$today','$safr_id','$area')");
    $msg = $r ? "Evacuation request submitted! Request ID: <strong>$evareq_id</strong>" : 'Error: ' . $conn->error;
}

// Get all vehicles
$vehicles = [];
$qv = $conn->query("SELECT v.*, c.Location FROM Vehicle v LEFT JOIN Camp c ON v.Camp_id=c.Camp_id");
while ($row = $qv->fetch_assoc()) $vehicles[] = $row;

// Get all evac requests
$evac_requests = [];
$qe = $conn->query("SELECT e.*, r.Full_name FROM Evac_Request e
    LEFT JOIN Refugee r ON e.Safr_id=r.Safr_id
    ORDER BY e.Request_date DESC LIMIT 50");
while ($row = $qe->fetch_assoc()) $evac_requests[] = $row;

$conn->close();
include __DIR__ . '/../includes/header.php';
?>
<div class="page-header">
  <div class="container">
    <div class="hero-badge" style="margin-bottom:.75rem;">Module 03</div>
    <h1>Civilian Evacuation Transport</h1>
    <p>Request emergency evacuation. Priority goes to minors, elders, and the chronically ill.</p>
  </div>
</div>

<div class="section">
  <div class="container">
    <?php if ($msg): ?><div class="alert alert-success" data-auto-dismiss><?= $msg ?></div><?php endif; ?>

    <!-- Priority notice -->
    <div class="alert alert-info fade-up" style="margin-bottom:2rem;">
      <span>⚡</span>
      <span>Evacuation priority: <strong>Minors & infants → Elderly (60+) → Chronically ill → Others</strong>. Please select the correct priority when submitting.</span>
    </div>

    <div class="tab-container" data-tabs>
      <div class="tabs">
        <button class="tab-btn active" data-tab="tab-request-form">📋 Request Evacuation</button>
        <button class="tab-btn" data-tab="tab-all-requests">All Requests</button>
        <button class="tab-btn" data-tab="tab-vehicles">Available Vehicles</button>
      </div>

      <!-- Request Form -->
      <div class="tab-panel active" id="tab-request-form">
        <div class="card card-body" style="max-width:600px;">
          <h3 style="margin-bottom:1.25rem;">Submit an Evacuation Request</h3>
          <form method="POST">
            <div class="form-group">
              <label class="form-label">SAFR ID</label>
              <input type="text" name="safr_id" class="form-control" placeholder="Your SAFR ID"
                value="<?= htmlspecialchars($_SESSION['user']['safr_id'] ?? '') ?>" required>
            </div>
            <div class="form-group">
              <label class="form-label">Current Location / Area</label>
              <input type="text" name="area" class="form-control" placeholder="e.g. Northern District, Aleppo" required>
            </div>
            <div class="form-group">
              <label class="form-label">Priority Level</label>
              <select name="priority" class="form-control" required>
                <option value="high">🔴 High – Minor / Infant</option>
                <option value="high">🔴 High – Elderly (60+)</option>
                <option value="high">🔴 High – Chronically Ill</option>
                <option value="medium" selected>🟡 Medium – General Civilian</option>
                <option value="low">🟢 Low – Non-urgent transfer</option>
              </select>
            </div>
            <button type="submit" name="request_evac" class="btn btn-primary">Submit Request &rarr;</button>
          </form>
        </div>
      </div>

      <!-- All Requests -->
      <div class="tab-panel" id="tab-all-requests">
        <div class="table-wrapper">
          <table class="safr-table">
            <thead><tr><th>Request ID</th><th>Refugee</th><th>SAFR ID</th><th>Priority</th><th>Area</th><th>Date</th><th>Status</th></tr></thead>
            <tbody>
              <?php if (empty($evac_requests)): ?>
                <tr><td colspan="7" style="text-align:center;padding:2rem;">No evacuation requests yet.</td></tr>
              <?php else: ?>
                <?php foreach ($evac_requests as $ev): ?>
                <tr>
                  <td><span class="badge badge-amber"><?= htmlspecialchars($ev['Evareq_id']) ?></span></td>
                  <td><?= htmlspecialchars($ev['Full_name'] ?? '—') ?></td>
                  <td><?= htmlspecialchars($ev['Safr_id'] ?? '—') ?></td>
                  <td>
                    <?php $p = strtolower($ev['Priority'] ?? 'medium');
                    if ($p==='high')   echo '<span class="badge priority-high">High</span>';
                    elseif($p==='low') echo '<span class="badge priority-low">Low</span>';
                    else               echo '<span class="badge priority-medium">Medium</span>'; ?>
                  </td>
                  <td><?= htmlspecialchars($ev['Operating_areas'] ?? '—') ?></td>
                  <td><?= htmlspecialchars($ev['Request_date'] ?? '—') ?></td>
                  <td><?= $ev['Status'] ? '<span class="badge badge-green">Allocated</span>' : '<span class="badge badge-amber">Pending</span>' ?></td>
                </tr>
                <?php endforeach; ?>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>

      <!-- Vehicles -->
      <div class="tab-panel" id="tab-vehicles">
        <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:1.25rem;">
          <?php if (empty($vehicles)): ?>
            <div class="alert alert-info">No vehicles registered yet.</div>
          <?php else: ?>
            <?php foreach ($vehicles as $v): ?>
            <div class="card card-body">
              <div style="display:flex;align-items:center;gap:.75rem;margin-bottom:1rem;">
                <div style="font-size:2rem;"><?= htmlspecialchars(substr($v['Vehicle_type'] ?? 'Vehicle', 0, 1)) ?></div>
                <div>
                  <strong style="color:var(--brown-dark);"><?= htmlspecialchars($v['Vehicle_type'] ?? 'Vehicle') ?></strong><br>
                  <span class="badge badge-gray"><?= htmlspecialchars($v['Vehicle_id']) ?></span>
                </div>
              </div>
              <div style="font-size:.85rem;color:var(--brown);">
                <div>Camp: <?= htmlspecialchars($v['Camp_id'] ?? '—') ?></div>
                <div>Location: <?= htmlspecialchars($v['Location'] ?? $v['Operating_Areas'] ?? '—') ?></div>
                <div>Capacity: <?= $v['Capacity'] ?? '—' ?></div>
              </div>
            </div>
            <?php endforeach; ?>
          <?php endif; ?>
        </div>
      </div>
    </div>
  </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
