<?php
// Shared helper: compute the app base path (e.g. "/SAFR") safely.
// This prevents broken redirects/links when the project is hosted in a subfolder.
if (!function_exists('safr_base_path')) {
  function safr_base_path(): string {
    $scriptName = str_replace('\\', '/', $_SERVER['SCRIPT_NAME'] ?? '');
    $marker = '/pages/';
    if (strpos($scriptName, $marker) !== false) {
      return rtrim(substr($scriptName, 0, strpos($scriptName, $marker)), '/');
    }
    $marker = '/auth/';
    if (strpos($scriptName, $marker) !== false) {
      return rtrim(substr($scriptName, 0, strpos($scriptName, $marker)), '/');
    }
    return rtrim(str_replace('\\', '/', dirname($scriptName)), '/.');
  }
}

