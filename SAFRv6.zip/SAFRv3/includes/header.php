<?php
if (session_status() === PHP_SESSION_NONE) session_start();
$current = basename($_SERVER['PHP_SELF']);

require_once __DIR__ . '/base_path.php';

$basePath = safr_base_path();
if ($basePath === '') $basePath = '/';

// Role-based UI control (donor/refugee should not see top navigation links/buttons)
$currentRole  = $_SESSION['user']['role'] ?? 'guest';
$isDonor       = $currentRole === 'donor';
$isRefugee     = $currentRole === 'refugee';
$hideTopNavFor = $isDonor || $isRefugee;
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="SAFR – Shelter, Aid and Family Reunification for Refugees. Connecting displaced families with camps, aid and support across borders.">
  <title><?= $pageTitle ?? 'SAFR – Shelter, Aid &amp; Family Reunification' ?></title>
  <link rel="stylesheet" href="<?= $cssPath ?? ($basePath . '/assets/css/style.css') ?>">
</head>
<body>

<?php $hideTopBar = $hideTopBar ?? false; ?>
<?php if (!$hideTopBar): ?>
<nav class="navbar" id="main-navbar">
  <a href="<?= $basePath ?>/index.php" class="nav-logo">
    <span class="logo-icon" aria-hidden="true">
      <svg class="safr-icon" viewBox="0 0 24 24" width="18" height="18" role="img" aria-label="">
        <path fill="currentColor" d="M12 7.25c2.62 0 4.75 2.13 4.75 4.75S14.62 16.75 12 16.75 7.25 14.62 7.25 12 9.38 7.25 12 7.25Zm0 2a2.75 2.75 0 1 0 0 5.5 2.75 2.75 0 0 0 0-5.5Zm0-7.1 1.05 2.3a.9.9 0 0 0 .7.52l2.52.31-1.87 1.75a.9.9 0 0 0-.27.82l.5 2.48-2.23-1.25a.9.9 0 0 0-.87 0l-2.23 1.25.5-2.48a.9.9 0 0 0-.27-.82L7.73 5.28l2.52-.31a.9.9 0 0 0 .7-.52L12 2.15Z"/>
      </svg>
    </span>
    SAFR
  </a>

  <?php if (!$hideTopNavFor): ?>
    <ul class="nav-links">
      <li><a href="<?= $basePath ?>/index.php" <?= $current==='index.php'?'class="active"':'' ?>>Home</a></li>
      <li><a href="<?= $basePath ?>/pages/refugee.php" <?= $current==='refugee.php'?'class="active"':'' ?>>Refugees</a></li>
      <li><a href="<?= $basePath ?>/pages/medical.php" <?= $current==='medical.php'?'class="active"':'' ?>>Medical</a></li>
      <li><a href="<?= $basePath ?>/pages/evacuation.php" <?= $current==='evacuation.php'?'class="active"':'' ?>>Evacuation</a></li>
      <li><a href="<?= $basePath ?>/pages/aid.php" <?= $current==='aid.php'?'class="active"':'' ?>>Aid</a></li>
      <li><a href="<?= $basePath ?>/pages/volunteer.php" <?= $current==='volunteer.php'?'class="active"':'' ?>>Volunteers</a></li>
      <li><a href="<?= $basePath ?>/pages/family.php" <?= $current==='family.php'?'class="active"':'' ?>>Family Search</a></li>
      <li><a href="<?= $basePath ?>/pages/donate.php" <?= $current==='donate.php'?'class="active"':'' ?>>Donate</a></li>
    </ul>

    <div class="nav-cta">
      <?php if (isset($_SESSION['user'])): ?>
        <a href="<?= $basePath ?>/pages/dashboard.php" class="btn-nav-login">Dashboard</a>
        <a href="<?= $basePath ?>/auth/logout.php" class="btn-nav-signup">Logout</a>
      <?php else: ?>
        <a href="<?= $basePath ?>/auth/login.php" class="btn-nav-login">Log In</a>
        <a href="<?= $basePath ?>/auth/signup.php" class="btn-nav-signup">Register</a>
      <?php endif; ?>
    </div>

    <button class="nav-hamburger" id="hamburger-btn" aria-label="Menu">
      <span></span><span></span><span></span>
    </button>
  <?php endif; ?>
</nav>
<?php endif; ?>
