
<footer>
  <div class="container">
    <div class="footer-grid">
      <div class="footer-brand">
        <div class="brand-name">SAFR</div>
        <p>Shelter, Aid &amp; Family Reunification for Refugees.<br>
        Helping displaced families find safety, support, and each other across borders.</p>
      </div>
      <div class="footer-col">
        <h4>Platform</h4>
        <ul>
          <li><a href="<?= $basePath ?>/pages/refugee.php">Refugee Tracking</a></li>
          <li><a href="<?= $basePath ?>/pages/medical.php">Medical Resources</a></li>
          <li><a href="<?= $basePath ?>/pages/evacuation.php">Evacuation</a></li>
          <li><a href="<?= $basePath ?>/pages/aid.php">Aid Distribution</a></li>
        </ul>
      </div>
      <div class="footer-col">
        <h4>Community</h4>
        <ul>
          <li><a href="<?= $basePath ?>/pages/volunteer.php">Volunteers</a></li>
          <li><a href="<?= $basePath ?>/pages/family.php">Family Search</a></li>
          <li><a href="<?= $basePath ?>/pages/donate.php">Donate</a></li>
        </ul>
      </div>
      <div class="footer-col">
        <h4>Account</h4>
        <ul>
          <li><a href="<?= $basePath ?>/auth/login.php">Log In</a></li>
          <li><a href="<?= $basePath ?>/auth/signup.php">Register</a></li>
          <li><a href="<?= $basePath ?>/pages/dashboard.php">Dashboard</a></li>
        </ul>
      </div>
    </div>
    <div class="footer-bottom">
      <span>&copy; <?= date('Y') ?> SAFR. Built with purpose.</span>
      <span>Every life matters</span>
    </div>
  </div>
</footer>

<script src="<?= $basePath ?>/assets/js/main.js"></script>
</body>
</html>
