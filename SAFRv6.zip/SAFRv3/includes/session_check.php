<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/base_path.php';
if (!isset($_SESSION['user'])) {
    $basePath = safr_base_path();
    if ($basePath === '') $basePath = '/';
    header('Location: ' . $basePath . '/auth/login.php');
    exit;
}
