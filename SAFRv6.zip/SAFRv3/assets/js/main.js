/* =============================================
   SAFR – Global JavaScript
   ============================================= */

document.addEventListener('DOMContentLoaded', () => {

  /* ─── Navbar scroll effect ─── */
  const navbar = document.querySelector('.navbar');
  if (navbar) {
    window.addEventListener('scroll', () => {
      navbar.classList.toggle('scrolled', window.scrollY > 40);
    });
  }

  /* ─── Mobile hamburger ─── */
  const hamburger = document.querySelector('.nav-hamburger');
  const navLinksEl = document.querySelector('.nav-links');
  if (hamburger && navLinksEl) {
    hamburger.addEventListener('click', () => {
      navLinksEl.classList.toggle('mobile-open');
    });
  }

  /* ─── Fade-up on scroll ─── */
  const fadeEls = document.querySelectorAll('.fade-up');
  const io = new IntersectionObserver((entries) => {
    entries.forEach(e => {
      if (e.isIntersecting) { e.target.classList.add('visible'); io.unobserve(e.target); }
    });
  }, { threshold: 0.12 });
  fadeEls.forEach(el => io.observe(el));

  /* ─── Tabs ─── */
  document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const group = btn.closest('[data-tabs]') || btn.closest('.tab-container');
      if (!group) return;
      group.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
      group.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));
      btn.classList.add('active');
      const target = group.querySelector(`#${btn.dataset.tab}`);
      if (target) target.classList.add('active');
    });
  });

  /* ─── Modals ─── */
  document.querySelectorAll('[data-modal-open]').forEach(btn => {
    btn.addEventListener('click', () => {
      const modal = document.getElementById(btn.dataset.modalOpen);
      if (modal) modal.classList.add('open');
    });
  });
  document.querySelectorAll('[data-modal-close], .modal-close').forEach(btn => {
    btn.addEventListener('click', () => {
      const overlay = btn.closest('.modal-overlay');
      if (overlay) overlay.classList.remove('open');
    });
  });
  document.querySelectorAll('.modal-overlay').forEach(ov => {
    ov.addEventListener('click', e => { if (e.target === ov) ov.classList.remove('open'); });
  });

  /* ─── Role tabs on auth pages ─── */
  const roleTabs = document.querySelectorAll('.role-tab');
  roleTabs.forEach(tab => {
    tab.addEventListener('click', () => {
      roleTabs.forEach(t => t.classList.remove('active'));
      tab.classList.add('active');
      const role = tab.dataset.role;
      document.querySelectorAll('.role-section').forEach(s => {
        s.classList.toggle('hidden', s.dataset.roleSection !== role);
      });
      const roleInput = document.getElementById('selected-role');
      if (roleInput) roleInput.value = role;
      const signupRoleInput = document.getElementById('signup-role');
      if (signupRoleInput) signupRoleInput.value = role;
    });
  });

  /* ─── Flash messages auto-dismiss ─── */
  document.querySelectorAll('.alert[data-auto-dismiss]').forEach(alert => {
    setTimeout(() => {
      alert.style.opacity = '0';
      alert.style.transition = 'opacity 0.4s';
      setTimeout(() => alert.remove(), 400);
    }, 4000);
  });

  /* ─── Counter animation ─── */
  const counters = document.querySelectorAll('[data-count]');
  const cIo = new IntersectionObserver(entries => {
    entries.forEach(e => {
      if (e.isIntersecting) {
        const el = e.target;
        const target = +el.dataset.count;
        const duration = 1600;
        const step = target / (duration / 16);
        let cur = 0;
        const timer = setInterval(() => {
          cur += step;
          if (cur >= target) { cur = target; clearInterval(timer); }
          el.textContent = Math.floor(cur).toLocaleString();
        }, 16);
        cIo.unobserve(el);
      }
    });
  }, { threshold: 0.5 });
  counters.forEach(c => cIo.observe(c));

  /* ─── Form submit with fetch + spinner ─── */
  document.querySelectorAll('form[data-ajax]').forEach(form => {
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      const btn = form.querySelector('[type=submit]');
      const origText = btn.innerHTML;
      btn.innerHTML = '<span class="spinner"></span>';
      btn.disabled = true;

      const formData = new FormData(form);
      try {
        const res = await fetch(form.action, { method: form.method || 'POST', body: formData });
        const data = await res.json();
        showFormResult(form, data);
      } catch {
        showFormResult(form, { error: 'Network error. Please try again.' });
      } finally {
        btn.innerHTML = origText;
        btn.disabled = false;
      }
    });
  });

});

/* ─── Helpers ─── */
function showFormResult(form, data) {
  let alertEl = form.querySelector('.form-alert');
  if (!alertEl) {
    alertEl = document.createElement('div');
    alertEl.className = 'alert';
    form.prepend(alertEl);
  }
  if (data.success) {
    alertEl.className = 'alert alert-success';
    alertEl.textContent = data.success;
    if (data.redirect) setTimeout(() => window.location.href = data.redirect, 1200);
  } else {
    alertEl.className = 'alert alert-error';
    alertEl.textContent = data.error || 'Something went wrong.';
  }
}

function openModal(id) {
  const el = document.getElementById(id);
  if (el) el.classList.add('open');
}
function closeModal(id) {
  const el = document.getElementById(id);
  if (el) el.classList.remove('open');
}
