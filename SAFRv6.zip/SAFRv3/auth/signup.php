<?php
$pageTitle = 'Register – SAFR';
require_once __DIR__ . '/../config/db.php';
$error = ''; $success = '';
$scriptName = str_replace('\\', '/', $_SERVER['SCRIPT_NAME'] ?? '');
$basePath = rtrim(substr($scriptName, 0, strrpos($scriptName, '/auth/')), '/');
if ($basePath === '') $basePath = '/';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $role     = $_POST['role'] ?? '';
    $password = $_POST['password'] ?? '';
    $password2= $_POST['password2'] ?? '';
    $conn     = getDBConnection();

    if ($password !== $password2) { $error = 'Passwords do not match.'; }
    elseif (strlen($password) < 6)  { $error = 'Password must be at least 6 characters.'; }
    else {
        if ($role === 'refugee') {
            $name   = $conn->real_escape_string(trim($_POST['refugee_full_name'] ?? ''));
            $dob    = $conn->real_escape_string($_POST['refugee_dob'] ?? '');
            $blood  = $conn->real_escape_string($_POST['refugee_blood'] ?? '');
            $country= $conn->real_escape_string($_POST['refugee_country'] ?? '');
            $city   = $conn->real_escape_string($_POST['refugee_city'] ?? '');
            if (!$name) { $error = 'Full name is required.'; }
            else {
                $date_part = date('ymd'); // 8 chars
                // Keep within Refugee.Safr_id VARCHAR(20):
                // "SAFR"(4) + date_part(8) + rand_part(8) = 20
                $rand_part = strtoupper(substr(bin2hex(random_bytes(4)), 0, 8)); // 8 chars
                $safr_id   = "SAFR{$date_part}{$rand_part}";
                if (strlen($safr_id) > 20) {
                    throw new mysqli_sql_exception('Generated Safr_id exceeds 20 characters; check ID format.');
                }
                $reg_date  = date('Y-m-d');
                $pw        = $conn->real_escape_string($password);

                try {
                    $conn->begin_transaction();
                    // DB: Refugee(Safr_id, Full_name, Date_of_Birth, Blood_Group, Country, City, Reg_date)
                    $conn->query("INSERT INTO Refugee (Safr_id,Full_name,Date_of_Birth,Blood_Group,Country,City,Reg_date)
                                   VALUES ('$safr_id','$name','$dob','$blood','$country','$city','$reg_date')");
                    // DB: refugee_credential(Safr_id, Password)
                    $conn->query("INSERT INTO REFUGEE_credential (Safr_id,Password) VALUES ('$safr_id','$pw')");
                    $conn->commit();
                    $success = "Registered! Your SAFR ID: <strong>$safr_id</strong>. Please save it. <a href='{$basePath}/auth/login.php'>Login now</a>.";
                } catch (mysqli_sql_exception $e) {
                    $conn->rollback();
                    $error = 'Registration failed: ' . $e->getMessage();
                }
            }

        } elseif ($role === 'volunteer') {
            $name    = $conn->real_escape_string(trim($_POST['vol_full_name'] ?? ''));
            $email   = $conn->real_escape_string($_POST['vol_email'] ?? '');
            $phone   = $conn->real_escape_string($_POST['vol_phone'] ?? '');
            $country = $conn->real_escape_string($_POST['vol_country'] ?? '');
            if (!$name) { $error = 'Full name is required.'; }
            else {
                $vid = 'VOL-' . strtoupper(substr(md5(uniqid()),0,8));
                // DB: Volunteer(Volunteer_id, Name, Email, Phone, Home_Country)
                $r = $conn->query("INSERT INTO Volunteer (Volunteer_id,Name,Email,Phone,Home_Country)
                                   VALUES ('$vid','$name','$email','$phone','$country')");
                if ($r) {
                    $pw = $conn->real_escape_string($password);
                    // DB: Volunteer_credential(Volunteer_id, Password)
                    $conn->query("INSERT INTO Volunteer_credential (Volunteer_id,Password) VALUES ('$vid','$pw')");
                    $success = "Volunteer registered! Your ID: <strong>$vid</strong>. <a href='{$basePath}/auth/login.php'>Login</a>.";
                } else { $error = 'Registration failed: ' . $conn->error; }
            }

        } elseif ($role === 'ngo') {
            $ngo_name = $conn->real_escape_string(trim($_POST['ngo_name'] ?? ''));
            $email    = $conn->real_escape_string($_POST['ngo_email'] ?? '');
            $manager  = $conn->real_escape_string($_POST['ngo_manager'] ?? '');
            $areas    = $conn->real_escape_string($_POST['ngo_areas'] ?? '');
            if (!$ngo_name) { $error = 'NGO name is required.'; }
            else {
                // DB: NGO(NGO_name, Contact_Email, Manager_name, Operating_Areas, Camp_id, Item_req, Item_quantity)
                $r = $conn->query("INSERT INTO NGO (NGO_name,Contact_Email,Manager_name,Operating_Areas)
                                   VALUES ('$ngo_name','$email','$manager','$areas')");
                if ($r) {
                    $pw = $conn->real_escape_string($password);
                    // DB: NGO_credential(NGO_name, Password)
                    $conn->query("INSERT INTO NGO_credential (NGO_name,Password) VALUES ('$ngo_name','$pw')");
                    $success = "NGO registered! <a href='{$basePath}/auth/login.php'>Login</a>.";
                } else { $error = 'Registration failed: ' . $conn->error; }
            }

        } elseif ($role === 'donor') {
            $name    = $conn->real_escape_string(trim($_POST['donor_full_name'] ?? ''));
            $phone   = $conn->real_escape_string($_POST['donor_phone'] ?? '');
            $email   = $conn->real_escape_string($_POST['donor_email'] ?? '');
            $dtype   = $conn->real_escape_string($_POST['donor_type'] ?? 'one-time');
            if (!$name) { $error = 'Full name is required.'; }
            else {
                // DB: Donor(Name, Phone, Email, Payment_Method, Total_Amount, Donation_type, Donor_type)
                $r = $conn->query("INSERT INTO Donor (Name,Phone,Email,Donor_type,Total_Amount)
                                   VALUES ('$name','$phone','$email','$dtype',0.00)");
                if ($r) {
                    $pw = $conn->real_escape_string($password);
                    // DB: Donor_credential(Full_name, Password)
                    $conn->query("INSERT INTO Donor_credential (Full_name,Password) VALUES ('$name','$pw')");
                    $success = "Donor registered! <a href='{$basePath}/auth/login.php'>Login</a>.";
                } else { $error = 'Registration failed: ' . $conn->error; }
            }
        } else { $error = 'Please select a role.'; }
        $conn->close();
    }
}
$hideTopBar = true;
include __DIR__ . '/../includes/header.php';
?>
<div class="auth-page">
  <div class="auth-visual">
    <div class="auth-visual-overlay"></div>
    <div class="auth-visual-content">
      <h2>Join SAFR</h2>
      <p>Register as a refugee, volunteer, NGO, or donor. Together we can rebuild lives and reunite families.</p>
      <div style="margin-top:1.5rem;">
        <div style="color:var(--gold-light);font-size:0.85rem;margin-bottom:.5rem;">✓ Secure ID generation</div>
        <div style="color:var(--gold-light);font-size:0.85rem;margin-bottom:.5rem;">✓ Cross-border sharing</div>
        <div style="color:var(--gold-light);font-size:0.85rem;">✓ 24/7 humanitarian support</div>
      </div>
    </div>
  </div>
  <div class="auth-form-panel" style="overflow-y:auto;">
    <div class="auth-form-box" style="max-width:460px;">
      <div class="auth-logo">SAFR</div>
      <h2>Create Account</h2>
      <p class="sub">Select your role to get started</p>
      <?php if ($error): ?><div class="alert alert-error"><?= $error ?></div><?php endif; ?>
      <?php if ($success): ?><div class="alert alert-success"><?= $success ?></div><?php endif; ?>

      <div class="role-tabs" id="signup-role-tabs">
        <button type="button" class="role-tab active" data-role="refugee">Refugee</button>
        <button type="button" class="role-tab" data-role="volunteer">Volunteer</button>
        <button type="button" class="role-tab" data-role="ngo">NGO</button>
        <button type="button" class="role-tab" data-role="donor">Donor</button>
      </div>

      <form method="POST" action="">
        <input type="hidden" name="role" id="signup-role" value="refugee">

        <!-- REFUGEE FIELDS -->
        <div class="role-section" data-role-section="refugee">
          <div class="form-group"><label class="form-label">Full Name (as in passport)</label>
            <input type="text" name="refugee_full_name" class="form-control" placeholder="Full legal name"></div>
          <div class="form-row">
            <div class="form-group"><label class="form-label">Date of Birth</label>
              <input type="date" name="refugee_dob" class="form-control"></div>
            <div class="form-group"><label class="form-label">Blood Group</label>
              <select name="refugee_blood" class="form-control">
                <option value="">Select</option>
                <?php foreach(['A+','A-','B+','B-','O+','O-','AB+','AB-'] as $bg): ?>
                  <option><?= $bg ?></option>
                <?php endforeach; ?>
              </select></div>
          </div>
          <div class="form-row">
            <div class="form-group"><label class="form-label">Country of Origin</label>
              <input type="text" name="refugee_country" class="form-control" placeholder="Country"></div>
            <div class="form-group"><label class="form-label">City of Origin</label>
              <input type="text" name="refugee_city" class="form-control" placeholder="City"></div>
          </div>
        </div>

        <!-- VOLUNTEER FIELDS -->
        <div class="role-section hidden" data-role-section="volunteer">
          <div class="form-group"><label class="form-label">Full Name</label>
            <input type="text" name="vol_full_name" class="form-control" placeholder="Your full name"></div>
          <div class="form-row">
            <div class="form-group"><label class="form-label">Email</label>
              <input type="email" name="vol_email" class="form-control" placeholder="Email"></div>
            <div class="form-group"><label class="form-label">Phone</label>
              <input type="text" name="vol_phone" class="form-control" placeholder="Phone"></div>
          </div>
          <div class="form-group"><label class="form-label">Home Country</label>
            <input type="text" name="vol_country" class="form-control" placeholder="Country"></div>
        </div>

        <!-- NGO FIELDS -->
        <div class="role-section hidden" data-role-section="ngo">
          <div class="form-group"><label class="form-label">NGO Name</label>
            <input type="text" name="ngo_name" class="form-control" placeholder="Organization name"></div>
          <div class="form-row">
            <div class="form-group"><label class="form-label">Contact Email</label>
              <input type="email" name="ngo_email" class="form-control" placeholder="Email"></div>
            <div class="form-group"><label class="form-label">Manager Name</label>
              <input type="text" name="ngo_manager" class="form-control" placeholder="Manager"></div>
          </div>
          <div class="form-group"><label class="form-label">Operating Areas</label>
            <input type="text" name="ngo_areas" class="form-control" placeholder="e.g. Syria, Turkey, Jordan"></div>
        </div>

        <!-- DONOR FIELDS -->
        <div class="role-section hidden" data-role-section="donor">
          <div class="form-group"><label class="form-label">Full Name</label>
            <input type="text" name="donor_full_name" class="form-control" placeholder="Your full name"></div>
          <div class="form-row">
            <div class="form-group"><label class="form-label">Phone</label>
              <input type="text" name="donor_phone" class="form-control" placeholder="Phone"></div>
            <div class="form-group"><label class="form-label">Email</label>
              <input type="email" name="donor_email" class="form-control" placeholder="Email"></div>
          </div>
          <div class="form-group"><label class="form-label">Donor Type</label>
            <select name="donor_type" class="form-control">
              <option value="one-time">One-time Donor</option>
              <option value="regular">Regular Donor</option>
            </select></div>
        </div>

        <!-- PASSWORD (all roles) -->
        <div class="form-row" style="margin-top:.5rem;">
          <div class="form-group"><label class="form-label">Password</label>
            <input type="password" name="password" class="form-control" placeholder="Min 6 characters" required></div>
          <div class="form-group"><label class="form-label">Confirm Password</label>
            <input type="password" name="password2" class="form-control" placeholder="Repeat password" required></div>
        </div>

        <button type="submit" class="btn btn-primary btn-block btn-lg mt-2">Register &rarr;</button>
      </form>
      <p class="auth-switch">Already registered? <a href="<?= $basePath ?>/auth/login.php">Login here</a></p>
    </div>
  </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
