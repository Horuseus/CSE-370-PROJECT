<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/base_path.php';
session_destroy();
$basePath = safr_base_path();
if ($basePath === '') $basePath = '/';
header('Location: ' . $basePath . '/index.php');
exit;
