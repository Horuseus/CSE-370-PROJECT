<?php
if (session_status() === PHP_SESSION_NONE) session_start();

$scriptName = str_replace('\\', '/', $_SERVER['SCRIPT_NAME'] ?? '');
$basePath = rtrim(str_replace('\\', '/', dirname($scriptName)), '/.');
if ($basePath === '') $basePath = '/';

if (isset($_SESSION['user'])) {
    header('Location: ' . $basePath . '/pages/dashboard.php');
    exit;
}

header('Location: ' . $basePath . '/auth/login.php');
exit;
