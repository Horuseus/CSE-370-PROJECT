# SAFR – Shelter, Aid & Family Reunification for Refugees

> *"When war separates families and destroys homes, SAFR bridges the gap."*

---

## 🌻 Project Overview

SAFR is a full-stack humanitarian web platform built with **HTML, CSS, JavaScript, PHP, and MySQL**.  
It provides 7 integrated modules to help NGOs, camp managers, volunteers, refugees, and donors coordinate during crises.

---

## 📁 Project Structure

```
SAFR/
├── assets/
│   ├── css/style.css          ← Global stylesheet (earthy sunflower palette)
│   ├── js/main.js             ← Tabs, modals, counters, form helpers
│   └── images/hero_bg.png     ← Hero background image
├── auth/
│   ├── login.php              ← 4-role login (Refugee/Volunteer/NGO/Donor)
│   ├── signup.php             ← Registration for all 4 roles
│   └── logout.php
├── config/
│   └── db.php                 ← MySQL connection (edit credentials here)
├── includes/
│   ├── header.php             ← Shared navbar + <head>
│   ├── footer.php             ← Shared footer + scripts
│   └── session_check.php      ← Auth guard for protected pages
├── pages/
│   ├── dashboard.php          ← Role-specific dashboard
│   ├── refugee.php            ← Module 1: Refugee Tracking
│   ├── medical.php            ← Module 2: Medical Resource Management
│   ├── evacuation.php         ← Module 3: Civilian Evacuation
│   ├── aid.php                ← Module 4: Humanitarian Aid Distribution
│   ├── volunteer.php          ← Module 5: Volunteer & Skill Matching
│   ├── family.php             ← Module 6: Family Reunification
│   └── donate.php             ← Module 7: Donations
├── index.php                  ← Public landing page
├── database.sql               ← Full MySQL schema (run this first)
├── .htaccess                  ← Apache URL routing & security
└── README.md
```

---

## ⚙️ Setup Instructions

### 1. Requirements
- **XAMPP / WAMP / LAMP** (Apache + MySQL + PHP 8.0+)
- Place the `SAFR/` folder in your Apache web root:  
  - XAMPP: `C:/xampp/htdocs/SAFR/` (Windows) or `/opt/lampp/htdocs/SAFR/` (Linux)

### 2. Database Setup
1. Open **phpMyAdmin** → create a new database called `safr_db`
2. Import `database.sql`:  
   `phpMyAdmin → safr_db → Import → Choose database.sql → Go`

### 3. Configure Database Connection
Edit `config/db.php`:
```php
define('DB_HOST', 'localhost');
define('DB_USER', 'root');      // your MySQL username
define('DB_PASS', '');          // your MySQL password
define('DB_NAME', 'safr_db');
```

### 4. Enable mod_rewrite (Apache)
In `httpd.conf`, ensure:
```
AllowOverride All
```
is set for your htdocs directory. Then enable mod_rewrite.

### 5. Visit the Site
Open your browser: `http://localhost/SAFR/`

---

## 🔐 Login System

| Role      | Username Field | Checked Against      | Credential Table         |
|-----------|---------------|----------------------|--------------------------|
| Refugee   | Full Name     | `Refugee.Full_name`  | `REFUGEE_credential`     |
| Volunteer | Full Name     | `Volunteer.Name`     | `Volunteer_credential`   |
| NGO       | NGO Name      | `NGO.NGO_name`       | `NGO_credential`         |
| Donor     | Full Name     | `Donor.Name`         | `Donor_credential`       |

**Login flow:**  
1. User selects role and enters username + password  
2. System checks if username exists in the main entity table  
3. If found → checks password in the corresponding `_credential` table  
4. If matched → session created, redirect to dashboard  

---

## 🧩 Modules

| # | Module | Access |
|---|--------|--------|
| 1 | Refugee & Displacement Tracking | All |
| 2 | Medical Resource Management | Volunteer / NGO |
| 3 | Civilian Evacuation Transport | Refugee / NGO |
| 4 | Humanitarian Aid Distribution | NGO |
| 5 | Volunteer & Skill Matching | NGO / Volunteer |
| 6 | Family Reunification Search | Refugee |
| 7 | Donations | Donor / Public |

---

## 🎨 Colour Palette

| Colour       | Hex       | Usage                     |
|--------------|-----------|---------------------------|
| Cream        | `#FFF8F0` | Page background           |
| Light Gold   | `#F0D8A1` | Cards, accents            |
| Yellow Gold  | `#E5BA41` | Highlights, CTA gradient  |
| Amber        | `#DD9E59` | Primary buttons, badges   |
| Medium Brown | `#C08552` | Borders, secondary        |
| Dark Brown   | `#8C5A3C` | Body text, icons          |
| Deep Brown   | `#4B2E2B` | Headings, navbar dark     |

---

## 📌 Notes
- Passwords are stored **as plain text** in this prototype — for production, use `password_hash()` / `password_verify()`
- SAFR IDs are auto-generated on registration: `SAFR-{camp}-{YYYYMMDD}-{HHMMSS}-{seq}`
- The `.htaccess` blocks direct access to `.sql` and `.md` files

---

*Built for SAFR – Spring 2026*
