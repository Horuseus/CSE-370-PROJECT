<?php
// SAFR Database Configuration
define('DB_HOST', 'localhost');
define('DB_USER', 'root');       // Change to your MySQL username
define('DB_PASS', '');           // Change to your MySQL password
// Must match the imported SQL dump database name
define('DB_NAME', 'safr_project_final');

function safrEnsureSchema(mysqli $conn): void {
    // Bootstrap schema ONLY when the database is completely empty.
    // If any table already exists (partial import / manual setup), do not touch schema.
    $countRes = $conn->query("SELECT COUNT(*) AS c FROM information_schema.tables WHERE table_schema = DATABASE()");
    if ($countRes) {
        $row = $countRes->fetch_assoc();
        if (!empty($row) && (int)($row['c'] ?? 0) > 0) return;
    }

    $schemaPath = __DIR__ . '/../database.sql';
    if (!is_file($schemaPath)) return;

    $sql = file_get_contents($schemaPath);
    if ($sql === false) return;

    // Remove CREATE DATABASE / USE statements; we already selected DB.
    $sql = preg_replace('/^\s*CREATE\s+DATABASE.*?;\s*$/mi', '', $sql) ?? $sql;
    $sql = preg_replace('/^\s*USE\s+.*?;\s*$/mi', '', $sql) ?? $sql;

    // Stored procedures use DELIMITER; skip them for bootstrap (app doesn't require them).
    $sql = preg_replace('/DELIMITER\s+\\$\\$[\\s\\S]*?DELIMITER\s+;\\s*/mi', '', $sql) ?? $sql;

    // Execute remaining statements in-order.
    // Using multi_query avoids ordering bugs from naive splitting and prevents FK creation errors.
    $bootstrap = "SET FOREIGN_KEY_CHECKS=0;\n" . $sql . "\nSET FOREIGN_KEY_CHECKS=1;";
    if (!$conn->multi_query($bootstrap)) return;
    do {
        // flush results to allow next statement
        if ($res = $conn->store_result()) { $res->free(); }
    } while ($conn->more_results() && $conn->next_result());
}

function getDBConnection() {
    // Connect without selecting a DB first, so we can create/select it if missing.
    mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
    try {
        $conn = new mysqli(DB_HOST, DB_USER, DB_PASS);
        $conn->set_charset('utf8mb4');

        $db = DB_NAME;
        $conn->query("CREATE DATABASE IF NOT EXISTS `$db` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
        $conn->select_db($db);
        safrEnsureSchema($conn);

        return $conn;
    } catch (mysqli_sql_exception $e) {
        die('Database connection failed: ' . htmlspecialchars($e->getMessage()));
    }
}

// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
