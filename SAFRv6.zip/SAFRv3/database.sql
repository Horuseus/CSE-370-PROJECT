-- ============================================================
-- SAFR - Shelter, Aid and Family Reunification for Refugees
-- Full Database Schema
-- ============================================================

CREATE DATABASE IF NOT EXISTS safr_project_final CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE safr_project_final;

-- ─────────────────────────────────────────────
-- Core Entity Tables
-- ─────────────────────────────────────────────

CREATE TABLE Refugee (
    Safr_id       VARCHAR(20)  PRIMARY KEY,
    Full_name     VARCHAR(100) NOT NULL,
    Date_of_Birth DATE,
    Blood_Group   VARCHAR(5),
    Country       VARCHAR(50),
    City          VARCHAR(50),
    Reg_date      DATE
);

CREATE TABLE Volunteer (
    Volunteer_id  VARCHAR(20)  PRIMARY KEY,
    Name          VARCHAR(100) NOT NULL,
    Email         VARCHAR(100),
    Phone         VARCHAR(20),
    Home_Country  VARCHAR(50)
);

CREATE TABLE Donor (
    Name            VARCHAR(100) PRIMARY KEY,
    Phone           VARCHAR(20),
    Email           VARCHAR(100),
    Payment_Method  VARCHAR(50),
    Total_Amount    DECIMAL(12,2) DEFAULT 0.00,
    Donation_type   VARCHAR(50),
    Donor_type      VARCHAR(20)
);

CREATE TABLE Camp (
    Camp_id      VARCHAR(20)  PRIMARY KEY,
    Location     VARCHAR(100) NOT NULL,
    Capacity     INT,
    Volunteer_id VARCHAR(20),
    FOREIGN KEY (Volunteer_id) REFERENCES Volunteer(Volunteer_id)
);

CREATE TABLE NGO (
    NGO_name        VARCHAR(100) PRIMARY KEY,
    Contact_Email   VARCHAR(100),
    Manager_name    VARCHAR(100),
    Operating_Areas VARCHAR(100),
    Camp_id         VARCHAR(20) UNIQUE,
    Item_req        VARCHAR(40),
    Item_quantity   INT,
    FOREIGN KEY (Camp_id) REFERENCES Camp(Camp_id)
);

CREATE TABLE Aid (
    Item_name  VARCHAR(100),
    Category   VARCHAR(50),
    Unit       INT,
    Camp_id    VARCHAR(20),
    NGO_name   VARCHAR(100),
    PRIMARY KEY (Item_name, Camp_id, NGO_name),
    FOREIGN KEY (Camp_id)  REFERENCES Camp(Camp_id),
    FOREIGN KEY (NGO_name) REFERENCES NGO(NGO_name)
);

-- ─────────────────────────────────────────────
-- Medical Inventory
-- ─────────────────────────────────────────────

CREATE TABLE Camp_Medical_Inventory (
    Inventory_id  VARCHAR(20),
    Item_name     VARCHAR(100),
    Camp_id       VARCHAR(20),
    PRIMARY KEY (Inventory_id, Item_name),
    FOREIGN KEY (Camp_id) REFERENCES Camp(Camp_id)
);

CREATE TABLE Inventory_update (
    Inventory_id  VARCHAR(20),
    Item_name     VARCHAR(100),
    Last_updated  DATE,
    PRIMARY KEY (Inventory_id, Item_name),
    FOREIGN KEY (Inventory_id, Item_name)
        REFERENCES Camp_Medical_Inventory(Inventory_id, Item_name)
);

CREATE TABLE ITEM_amount (
    Inventory_id  VARCHAR(20),
    Item_name     VARCHAR(100),
    Quantity      INT,
    PRIMARY KEY (Inventory_id, Item_name),
    FOREIGN KEY (Inventory_id, Item_name)
        REFERENCES Camp_Medical_Inventory(Inventory_id, Item_name)
);

CREATE TABLE Camp_Medical_Inventory_Asks_For (
    Requesting_Inventory_id VARCHAR(20),
    Requested_Inventory_id  VARCHAR(20),
    Item_needed             VARCHAR(100),
    Units                   INTEGER,
    Status                  BOOLEAN DEFAULT FALSE,
    PRIMARY KEY (Requesting_Inventory_id, Requested_Inventory_id),
    FOREIGN KEY (Requesting_Inventory_id)
        REFERENCES Camp_Medical_Inventory(Inventory_id),
    FOREIGN KEY (Requested_Inventory_id)
        REFERENCES Camp_Medical_Inventory(Inventory_id)
);

-- ─────────────────────────────────────────────
-- Vehicles & Evacuation
-- ─────────────────────────────────────────────

CREATE TABLE Vehicle (
    Vehicle_id      VARCHAR(20)  PRIMARY KEY,
    Vehicle_type    VARCHAR(50),
    Capacity        INT,
    Operating_Areas VARCHAR(100),
    Camp_id         VARCHAR(20),
    FOREIGN KEY (Camp_id) REFERENCES Camp(Camp_id)
);

CREATE TABLE Evac_Request (
    Evareq_id       VARCHAR(20)  PRIMARY KEY,
    Status          BOOLEAN DEFAULT FALSE,
    Priority        VARCHAR(20),
    Request_date    DATE,
    Allocation_date DATE,
    Vehicle_id      VARCHAR(20),
    Safr_id         VARCHAR(20),
    Operating_areas VARCHAR(100),
    FOREIGN KEY (Vehicle_id) REFERENCES Vehicle(Vehicle_id),
    FOREIGN KEY (Safr_id)    REFERENCES Refugee(Safr_id)
);

ALTER TABLE Camp ADD COLUMN Evareq_id VARCHAR(20);
ALTER TABLE Camp ADD CONSTRAINT fk_camp_evareq
    FOREIGN KEY (Evareq_id) REFERENCES Evac_Request(Evareq_id);

CREATE TABLE Refugee_Has_Requested_Vehicle (
    Safr_id          VARCHAR(20),
    Vehicle_id       VARCHAR(20),
    Destination_camp VARCHAR(20),
    PRIMARY KEY (Safr_id, Vehicle_id),
    FOREIGN KEY (Safr_id)    REFERENCES Refugee(Safr_id),
    FOREIGN KEY (Vehicle_id) REFERENCES Vehicle(Vehicle_id)
);

-- ─────────────────────────────────────────────
-- Camp Operations
-- ─────────────────────────────────────────────

CREATE TABLE Refugee_Stay_in_Camp (
    Safr_id        VARCHAR(20),
    Camp_id        VARCHAR(20),
    Arrival_date   DATE,
    Departure_date DATE,
    PRIMARY KEY (Safr_id, Camp_id),
    FOREIGN KEY (Safr_id) REFERENCES Refugee(Safr_id),
    FOREIGN KEY (Camp_id) REFERENCES Camp(Camp_id)
);

CREATE TABLE Camp_Request (
    Camp_id        VARCHAR(20),
    NGO_name       VARCHAR(100),
    Item_Requested VARCHAR(100),
    Item_quantity  INT,
    PRIMARY KEY (Camp_id, NGO_name),
    FOREIGN KEY (Camp_id)  REFERENCES Camp(Camp_id),
    FOREIGN KEY (NGO_name) REFERENCES NGO(NGO_name)
);

-- ─────────────────────────────────────────────
-- Family Search
-- ─────────────────────────────────────────────

CREATE TABLE Match_details (
    Safr_id       VARCHAR(20)  PRIMARY KEY,
    Camp_location VARCHAR(100),
    FOREIGN KEY (Safr_id) REFERENCES Refugee(Safr_id)
);

CREATE TABLE Identity_Doc (
    Safr_id    VARCHAR(20),
    Doc_number VARCHAR(50),
    Doc_type   VARCHAR(50),
    PRIMARY KEY (Safr_id, Doc_number),
    FOREIGN KEY (Safr_id) REFERENCES Refugee(Safr_id)
);

CREATE TABLE Search_Req (
    Safr_id       VARCHAR(20),
    Status        BOOLEAN DEFAULT FALSE,
    Missing_Name  VARCHAR(100),
    Doc_number    VARCHAR(50),
    Match_Safr_id VARCHAR(20),
    PRIMARY KEY (Safr_id),
    FOREIGN KEY (Safr_id) REFERENCES Refugee(Safr_id),
    FOREIGN KEY (Safr_id, Doc_number)
        REFERENCES Identity_Doc(Safr_id, Doc_number),
    FOREIGN KEY (Match_Safr_id) REFERENCES Match_details(Safr_id)
);

-- ─────────────────────────────────────────────
-- Volunteers & Assignments
-- ─────────────────────────────────────────────

CREATE TABLE Assignment (
    Assignment_ID VARCHAR(20),
    Volunteer_id  VARCHAR(20),
    Assigned_Date DATE,
    Camp_id       VARCHAR(20),
    PRIMARY KEY (Assignment_ID, Volunteer_id),
    FOREIGN KEY (Volunteer_id) REFERENCES Volunteer(Volunteer_id),
    FOREIGN KEY (Camp_id)      REFERENCES Camp(Camp_id)
);

CREATE TABLE Assignment_required_skill (
    Assignment_ID VARCHAR(20) PRIMARY KEY,
    Skill_name    VARCHAR(100),
    FOREIGN KEY (Assignment_ID) REFERENCES Assignment(Assignment_ID)
);

CREATE TABLE Volunteers_quota (
    Volunteer_id  VARCHAR(20) PRIMARY KEY,
    Outcome       VARCHAR(255),
    FOREIGN KEY (Volunteer_id) REFERENCES Assignment(Volunteer_id)
);

-- ─────────────────────────────────────────────
-- NGO & Donor
-- ─────────────────────────────────────────────

CREATE TABLE NGO_Inventory (
    NGO_name  VARCHAR(100),
    Item_name VARCHAR(100),
    Category  VARCHAR(50),
    Unit      INTEGER,
    PRIMARY KEY (NGO_name, Item_name),
    FOREIGN KEY (NGO_name) REFERENCES NGO(NGO_name)
);

CREATE TABLE Donor_NGO (
    NGO_name   VARCHAR(100),
    Donor_Name VARCHAR(100),
    PRIMARY KEY (NGO_name, Donor_Name),
    FOREIGN KEY (NGO_name)   REFERENCES NGO(NGO_name),
    FOREIGN KEY (Donor_Name) REFERENCES Donor(Name)
);

-- ─────────────────────────────────────────────
-- Credential Tables (Authentication)
-- ─────────────────────────────────────────────

CREATE TABLE REFUGEE_credential (
    Safr_id VARCHAR(20) PRIMARY KEY,
    Password  VARCHAR(255) NOT NULL,
    FOREIGN KEY (Safr_id) REFERENCES Refugee(Safr_id)
);

CREATE TABLE Volunteer_credential (
    Volunteer_id VARCHAR(100) PRIMARY KEY,
    Password  VARCHAR(255) NOT NULL,
    FOREIGN KEY (Volunteer_id) REFERENCES Volunteer(Volunteer_id)
);

CREATE TABLE NGO_credential (
    NGO_name VARCHAR(100) PRIMARY KEY,
    Password VARCHAR(255) NOT NULL,
    FOREIGN KEY (NGO_name) REFERENCES NGO(NGO_name)
);

CREATE TABLE Donor_credential (
    Full_name VARCHAR(100) PRIMARY KEY,
    Password  VARCHAR(255) NOT NULL,
    FOREIGN KEY (Full_name) REFERENCES Donor(Name)
);

-- ─────────────────────────────────────────────
-- Stored Procedures for Login
-- ─────────────────────────────────────────────

DELIMITER $$

CREATE PROCEDURE refugee_login(IN p_name VARCHAR(100), IN p_pass VARCHAR(255), OUT p_result VARCHAR(50))
BEGIN
    DECLARE v_exists INT DEFAULT 0;
    DECLARE v_pass_match INT DEFAULT 0;
    SELECT COUNT(*) INTO v_exists FROM Refugee WHERE Full_name = p_name;
    IF v_exists = 0 THEN
        SET p_result = 'username_incorrect';
    ELSE
        SELECT COUNT(*) INTO v_pass_match
        FROM REFUGEE_credential
        WHERE Full_name = p_name AND Password = p_pass;
        IF v_pass_match = 1 THEN
            SET p_result = 'success';
        ELSE
            SET p_result = 'password_incorrect';
        END IF;
    END IF;
END$$

CREATE PROCEDURE volunteer_login(IN p_name VARCHAR(100), IN p_pass VARCHAR(255), OUT p_result VARCHAR(50))
BEGIN
    DECLARE v_exists INT DEFAULT 0;
    DECLARE v_pass_match INT DEFAULT 0;
    SELECT COUNT(*) INTO v_exists FROM Volunteer WHERE Name = p_name;
    IF v_exists = 0 THEN
        SET p_result = 'username_incorrect';
    ELSE
        SELECT COUNT(*) INTO v_pass_match
        FROM Volunteer_credential
        WHERE Full_name = p_name AND Password = p_pass;
        IF v_pass_match = 1 THEN
            SET p_result = 'success';
        ELSE
            SET p_result = 'password_incorrect';
        END IF;
    END IF;
END$$

CREATE PROCEDURE ngo_login(IN p_name VARCHAR(100), IN p_pass VARCHAR(255), OUT p_result VARCHAR(50))
BEGIN
    DECLARE v_exists INT DEFAULT 0;
    DECLARE v_pass_match INT DEFAULT 0;
    SELECT COUNT(*) INTO v_exists FROM NGO WHERE NGO_name = p_name;
    IF v_exists = 0 THEN
        SET p_result = 'username_incorrect';
    ELSE
        SELECT COUNT(*) INTO v_pass_match
        FROM NGO_credential
        WHERE NGO_name = p_name AND Password = p_pass;
        IF v_pass_match = 1 THEN
            SET p_result = 'success';
        ELSE
            SET p_result = 'password_incorrect';
        END IF;
    END IF;
END$$

CREATE PROCEDURE donor_login(IN p_name VARCHAR(100), IN p_pass VARCHAR(255), OUT p_result VARCHAR(50))
BEGIN
    DECLARE v_exists INT DEFAULT 0;
    DECLARE v_pass_match INT DEFAULT 0;
    SELECT COUNT(*) INTO v_exists FROM Donor WHERE Name = p_name;
    IF v_exists = 0 THEN
        SET p_result = 'username_incorrect';
    ELSE
        SELECT COUNT(*) INTO v_pass_match
        FROM Donor_credential
        WHERE Full_name = p_name AND Password = p_pass;
        IF v_pass_match = 1 THEN
            SET p_result = 'success';
        ELSE
            SET p_result = 'password_incorrect';
        END IF;
    END IF;
END$$

DELIMITER ;

-- ─────────────────────────────────────────────
-- Seed Data (values only)
-- ─────────────────────────────────────────────
