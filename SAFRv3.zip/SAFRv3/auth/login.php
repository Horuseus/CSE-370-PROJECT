<?php
$pageTitle = 'Login – SAFR';
require_once __DIR__ . '/../config/db.php';
$error = '';
$scriptName = str_replace('\\', '/', $_SERVER['SCRIPT_NAME'] ?? '');
$basePath = rtrim(substr($scriptName, 0, strrpos($scriptName, '/auth/')), '/');
if ($basePath === '') $basePath = '/';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $role     = $_POST['role'] ?? '';
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    if (!$username || !$password || !$role) {
        $error = 'Please fill in all fields and select a role.';
    } else {
        $conn = getDBConnection();
        $us = $conn->real_escape_string($username);
        $found = false;

        if ($role === 'refugee') {
            // Refugee table: PK=Safr_id, name col=Full_name
            // refugee_credential: PK=Safr_id, Password
            $r = $conn->query("SELECT Safr_id, Full_name FROM Refugee WHERE Full_name='$us'");
            if ($r && $r->num_rows > 0) {
                $found = true;
                $refugee = $r->fetch_assoc();
                $sid = $conn->real_escape_string($refugee['Safr_id']);
                $c = $conn->query("SELECT Password FROM REFUGEE_credential WHERE Safr_id='$sid'");
                if ($c && $c->num_rows > 0 && $c->fetch_assoc()['Password'] === $password) {
                    $_SESSION['user'] = ['name'=>$username,'role'=>'refugee','safr_id'=>$refugee['Safr_id']];
                    header('Location: ' . $basePath . '/pages/dashboard.php'); exit;
                } else { $error = 'Incorrect password.'; }
            }

        } elseif ($role === 'volunteer') {
            $r = $conn->query("SELECT Volunteer_id, Name FROM Volunteer WHERE Name='$us'");
            if ($r && $r->num_rows > 0) {
                $found = true;
                $vol = $r->fetch_assoc();
                $vid = $conn->real_escape_string($vol['Volunteer_id']);
                $c = $conn->query("SELECT Password FROM Volunteer_credential WHERE Volunteer_id='$vid'");
                if ($c && $c->num_rows > 0 && $c->fetch_assoc()['Password'] === $password) {
                    $_SESSION['user'] = ['name'=>$username,'role'=>'volunteer','volunteer_id'=>$vol['Volunteer_id']];
                    header('Location: ' . $basePath . '/pages/dashboard.php'); exit;
                } else { $error = 'Incorrect password.'; }
            }

        } elseif ($role === 'ngo') {
            // NGO table: PK=NGO_name
            // NGO_credential: PK=NGO_name, Password
            $r = $conn->query("SELECT NGO_name FROM NGO WHERE NGO_name='$us'");
            if ($r && $r->num_rows > 0) {
                $found = true;
                $c = $conn->query("SELECT Password FROM NGO_credential WHERE NGO_name='$us'");
                if ($c && $c->num_rows > 0 && $c->fetch_assoc()['Password'] === $password) {
                    $_SESSION['user'] = ['name'=>$username,'role'=>'ngo'];
                    header('Location: ' . $basePath . '/pages/dashboard.php'); exit;
                } else { $error = 'Incorrect password.'; }
            }

        } elseif ($role === 'donor') {
            // Donor table: PK=Name
            // Donor_credential: PK=Full_name, Password
            $r = $conn->query("SELECT Name FROM Donor WHERE Name='$us'");
            if ($r && $r->num_rows > 0) {
                $found = true;
                $c = $conn->query("SELECT Password FROM Donor_credential WHERE Full_name='$us'");
                if ($c && $c->num_rows > 0 && $c->fetch_assoc()['Password'] === $password) {
                    $_SESSION['user'] = ['name'=>$username,'role'=>'donor'];
                    header('Location: ' . $basePath . '/pages/dashboard.php'); exit;
                } else { $error = 'Incorrect password.'; }
            }
        }
        if (!$found && !$error) $error = 'Username not found. Please check your name or register first.';
        $conn->close();
    }
}
$hideTopBar = true;
include __DIR__ . '/../includes/header.php';
?>
<div class="auth-page">
  <div class="auth-visual">
    <div class="auth-visual-overlay"></div>
    <div class="auth-visual-content">
      <h2>Welcome Back</h2>
      <p>Log in to access your dashboard, track refugees, manage resources, or find family members across the SAFR network.</p>
    </div>
  </div>
  <div class="auth-form-panel">
    <div class="auth-form-box">
      <div class="auth-logo">SAFR</div>
      <h2>Sign In</h2>
      <p class="sub">Choose your role and enter your credentials</p>
      <?php if ($error): ?><div class="alert alert-error"><?= htmlspecialchars($error) ?></div><?php endif; ?>
      <form method="POST" action="">
        <div class="role-tabs">
          <button type="button" class="role-tab <?= (!isset($_POST['role']) || $_POST['role']==='refugee')?'active':'' ?>" data-role="refugee">Refugee</button>
          <button type="button" class="role-tab <?= (isset($_POST['role']) && $_POST['role']==='volunteer')?'active':'' ?>" data-role="volunteer">Volunteer</button>
          <button type="button" class="role-tab <?= (isset($_POST['role']) && $_POST['role']==='ngo')?'active':'' ?>" data-role="ngo">NGO</button>
          <button type="button" class="role-tab <?= (isset($_POST['role']) && $_POST['role']==='donor')?'active':'' ?>" data-role="donor">Donor</button>
        </div>
        <input type="hidden" name="role" id="selected-role" value="<?= htmlspecialchars($_POST['role'] ?? 'refugee') ?>">
        <div class="form-group">
          <label class="form-label" id="lbl-username">Full Name</label>
          <input type="text" name="username" class="form-control" placeholder="Enter your full name" required value="<?= htmlspecialchars($_POST['username'] ?? '') ?>">
        </div>
        <div class="form-group">
          <label class="form-label">Password</label>
          <input type="password" name="password" class="form-control" placeholder="Enter your password" required>
        </div>
        <button type="submit" class="btn btn-primary btn-block btn-lg mt-2">Sign In &rarr;</button>
      </form>
      <p class="auth-switch">No account? <a href="<?= $basePath ?>/auth/signup.php">Register here</a></p>
    </div>
  </div>
</div>
<script>
document.querySelectorAll('.role-tab').forEach(t => t.addEventListener('click', () => {
  document.getElementById('selected-role').value = t.dataset.role;
  document.getElementById('lbl-username').textContent = t.dataset.role === 'ngo' ? 'NGO Name' : 'Full Name';
}));
</script>
<?php include __DIR__ . '/../includes/footer.php'; ?>
