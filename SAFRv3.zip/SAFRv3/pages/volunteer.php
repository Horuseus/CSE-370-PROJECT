<?php
$pageTitle = 'Volunteers – SAFR';
require_once __DIR__ . '/../config/db.php';
if (session_status() === PHP_SESSION_NONE) session_start();
$conn = getDBConnection();
$msg = '';

// Create assignment
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['create_assignment'])) {
    $aid   = 'ASN-'.strtoupper(substr(md5(uniqid()),0,6));
    $vid   = $conn->real_escape_string($_POST['volunteer_id'] ?? '');
    $camp  = $conn->real_escape_string($_POST['camp_id'] ?? '');
    $skill = $conn->real_escape_string($_POST['skill_name'] ?? '');
    $today = date('Y-m-d');
    $r1 = $conn->query("INSERT INTO Assignment (Assignment_ID,Volunteer_id,Assigned_Date,Camp_id)
                        VALUES ('$aid','$vid','$today','$camp')");
    if ($r1) {
        $conn->query("INSERT IGNORE INTO Assignment_required_skill (Assignment_ID,Skill_name) VALUES ('$aid','$skill')");
        $msg = "Assignment created! ID: <strong>$aid</strong>";
    } else { $msg = 'Error: ' . $conn->error; }
}

// Record outcome
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['record_outcome'])) {
    $vid     = $conn->real_escape_string($_POST['vol_id'] ?? '');
    $outcome = $conn->real_escape_string($_POST['outcome'] ?? '');
    $conn->query("INSERT INTO Volunteers_quota (Volunteer_id,Outcome) VALUES ('$vid','$outcome')
                  ON DUPLICATE KEY UPDATE Outcome='$outcome'");
    $msg = 'Outcome recorded.';
}

// Fetch volunteers with assignment counts
$volunteers = [];
$q = $conn->query("SELECT v.*, COUNT(a.Assignment_ID) AS assignment_count
    FROM Volunteer v LEFT JOIN Assignment a ON v.Volunteer_id=a.Volunteer_id
    GROUP BY v.Volunteer_id ORDER BY assignment_count DESC LIMIT 50");
while ($row = $q->fetch_assoc()) $volunteers[] = $row;

// Fetch assignments with skills
$assignments = [];
$qa = $conn->query("SELECT a.*, v.Name, s.Skill_name, c.Location
    FROM Assignment a
    LEFT JOIN Volunteer v ON a.Volunteer_id=v.Volunteer_id
    LEFT JOIN Assignment_required_skill s ON a.Assignment_ID=s.Assignment_ID
    LEFT JOIN Camp c ON a.Camp_id=c.Camp_id
    ORDER BY a.Assigned_Date DESC LIMIT 50");
while ($row = $qa->fetch_assoc()) $assignments[] = $row;

// Camps
$camps = [];
$qc = $conn->query("SELECT Camp_id, Location FROM Camp");
while ($row = $qc->fetch_assoc()) $camps[] = $row;
$conn->close();
include __DIR__ . '/../includes/header.php';
?>
<div class="page-header">
  <div class="container">
    <div class="hero-badge" style="margin-bottom:.75rem;">Module 05</div>
    <h1>Crisis Volunteer & Skill Matching</h1>
    <p>Match skilled volunteers to where they are needed most across all refugee camps.</p>
  </div>
</div>

<div class="section">
  <div class="container">
    <?php if ($msg): ?><div class="alert alert-success" data-auto-dismiss><?= $msg ?></div><?php endif; ?>

    <div class="tab-container" data-tabs>
      <div class="tabs">
        <button class="tab-btn active" data-tab="tab-volunteers">👥 All Volunteers</button>
        <button class="tab-btn" data-tab="tab-assignments">📋 Assignments</button>
        <button class="tab-btn" data-tab="tab-assign-form">➕ Create Assignment</button>
        <button class="tab-btn" data-tab="tab-outcome">✅ Record Outcome</button>
      </div>

      <!-- Volunteers Table -->
      <div class="tab-panel active" id="tab-volunteers">
        <div class="table-wrapper">
          <table class="safr-table">
            <thead><tr><th>Volunteer ID</th><th>Name</th><th>Email</th><th>Phone</th><th>Country</th><th>Assignments</th></tr></thead>
            <tbody>
              <?php if (empty($volunteers)): ?>
                <tr><td colspan="6" style="text-align:center;padding:2rem;">No volunteers registered yet.</td></tr>
              <?php else: ?>
                <?php foreach ($volunteers as $v): ?>
                <tr>
                  <td><span class="badge badge-amber"><?= htmlspecialchars($v['Volunteer_id']) ?></span></td>
                  <td><?= htmlspecialchars($v['Name']) ?></td>
                  <td><?= htmlspecialchars($v['Email'] ?? '—') ?></td>
                  <td><?= htmlspecialchars($v['Phone'] ?? '—') ?></td>
                  <td><?= htmlspecialchars($v['Home_Country'] ?? '—') ?></td>
                  <td><span class="badge badge-green"><?= $v['assignment_count'] ?></span></td>
                </tr>
                <?php endforeach; ?>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>

      <!-- Assignments Table -->
      <div class="tab-panel" id="tab-assignments">
        <div class="table-wrapper">
          <table class="safr-table">
            <thead><tr><th>Assignment ID</th><th>Volunteer</th><th>Skill Required</th><th>Camp</th><th>Location</th><th>Date</th></tr></thead>
            <tbody>
              <?php if (empty($assignments)): ?>
                <tr><td colspan="6" style="text-align:center;padding:2rem;">No assignments yet.</td></tr>
              <?php else: ?>
                <?php foreach ($assignments as $a): ?>
                <tr>
                  <td><span class="badge badge-gray"><?= htmlspecialchars($a['Assignment_ID']) ?></span></td>
                  <td><?= htmlspecialchars($a['Name'] ?? '—') ?></td>
                  <td><span class="badge badge-gold"><?= htmlspecialchars($a['Skill_name'] ?? '—') ?></span></td>
                  <td><?= htmlspecialchars($a['Camp_id'] ?? '—') ?></td>
                  <td><?= htmlspecialchars($a['Location'] ?? '—') ?></td>
                  <td><?= htmlspecialchars($a['Assigned_Date'] ?? '—') ?></td>
                </tr>
                <?php endforeach; ?>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>

      <!-- Create Assignment -->
      <div class="tab-panel" id="tab-assign-form">
        <div class="card card-body" style="max-width:580px;">
          <h3 style="margin-bottom:1.25rem;">Assign a Volunteer</h3>
          <form method="POST">
            <div class="form-group">
              <label class="form-label">Volunteer ID</label>
              <input type="text" name="volunteer_id" class="form-control" placeholder="e.g. VOL-XXXXXXXX" required>
            </div>
            <div class="form-group">
              <label class="form-label">Camp</label>
              <select name="camp_id" class="form-control" required>
                <option value="">Select Camp</option>
                <?php foreach ($camps as $c): ?>
                  <option value="<?= htmlspecialchars($c['Camp_id']) ?>"><?= htmlspecialchars($c['Camp_id'].' – '.$c['Location']) ?></option>
                <?php endforeach; ?>
              </select>
            </div>
            <div class="form-group">
              <label class="form-label">Required Skill / Role</label>
              <select name="skill_name" class="form-control">
                <option>Medical – Doctor</option>
                <option>Medical – Nurse</option>
                <option>Translation / Interpretation</option>
                <option>Logistics & Supply</option>
                <option>Counselling & Mental Health</option>
                <option>Education & Child Care</option>
                <option>Engineering & Construction</option>
                <option>Security & Protection</option>
                <option>Administration & Data</option>
                <option>General Labour</option>
              </select>
            </div>
            <button type="submit" name="create_assignment" class="btn btn-primary">Create Assignment</button>
          </form>
        </div>
      </div>

      <!-- Record Outcome -->
      <div class="tab-panel" id="tab-outcome">
        <div class="card card-body" style="max-width:500px;">
          <h3 style="margin-bottom:1.25rem;">Record Volunteer Outcome</h3>
          <form method="POST">
            <div class="form-group">
              <label class="form-label">Volunteer ID</label>
              <input type="text" name="vol_id" class="form-control" placeholder="Volunteer ID" required>
            </div>
            <div class="form-group">
              <label class="form-label">Outcome / Notes</label>
              <textarea name="outcome" class="form-control" placeholder="Describe the outcome of this volunteer's work..." required></textarea>
            </div>
            <button type="submit" name="record_outcome" class="btn btn-primary">Save Outcome</button>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
