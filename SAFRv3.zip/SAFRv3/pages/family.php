<?php
$pageTitle = 'Family Search – SAFR';
require_once __DIR__ . '/../config/db.php';
if (session_status() === PHP_SESSION_NONE) session_start();
$conn = getDBConnection();
$msg = ''; $results = [];

// Submit family search request
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_search'])) {
    $safr_id  = $conn->real_escape_string(trim($_POST['safr_id'] ?? ''));
    $miss_name= $conn->real_escape_string(trim($_POST['missing_name'] ?? ''));
    $doc_num  = $conn->real_escape_string(trim($_POST['doc_number'] ?? ''));

    // Check if doc exists in Identity_Doc for the searcher's safr_id
    $doc_check = $conn->query("SELECT Doc_number FROM Identity_Doc WHERE Safr_id='$safr_id' LIMIT 1");
    if (!$doc_check || $doc_check->num_rows === 0) {
        // Insert a placeholder doc if none exists so Search_Req FK is satisfied
        $conn->query("INSERT IGNORE INTO Identity_Doc (Safr_id,Doc_number,Doc_type) VALUES ('$safr_id','SEARCH-DOC','Search Request')");
        $doc_num_use = 'SEARCH-DOC';
    } else {
        $doc_num_use = $doc_num ?: $doc_check->fetch_assoc()['Doc_number'];
    }

    // Try to find a match in Refugee table by name
    $match_row = $conn->query("SELECT r.Safr_id, m.Camp_location FROM Refugee r
        LEFT JOIN Match_details m ON r.Safr_id=m.Safr_id
        WHERE r.Full_name LIKE '%$miss_name%' LIMIT 1");

    $match_safr = null;
    if ($match_row && $match_row->num_rows > 0) {
        $mdata = $match_row->fetch_assoc();
        $match_safr = $mdata['Safr_id'];
        // Ensure match_details entry exists
        $conn->query("INSERT IGNORE INTO Match_details (Safr_id,Camp_location) VALUES ('$match_safr','".($mdata['Camp_location'] ?? 'Unknown')."')");
    }

    $esc_match = $match_safr ? "'$match_safr'" : 'NULL';
    $esc_doc   = $conn->real_escape_string($doc_num_use);
    $status    = $match_safr ? 1 : 0;

    $r = $conn->query("INSERT INTO Search_Req (Safr_id,Status,Missing_Name,Doc_number,Match_Safr_id)
                       VALUES ('$safr_id',$status,'$miss_name','$esc_doc',$esc_match)
                       ON DUPLICATE KEY UPDATE Missing_Name='$miss_name', Status=$status, Match_Safr_id=$esc_match");

    if ($r) {
        $msg = $match_safr
            ? "Match found! SAFR ID: <strong>$match_safr</strong>. Check results below."
            : "Search request submitted. No immediate match found — your request is on record.";
    } else {
        $msg = 'Error: ' . $conn->error;
    }
}

// Search results by name or doc
$search = $conn->real_escape_string(trim($_GET['q'] ?? ''));
if ($search) {
    $q = $conn->query("SELECT r.Safr_id, r.Full_name, r.Country, r.City, r.Blood_Group,
        m.Camp_location, i.Doc_type, i.Doc_number
        FROM Refugee r
        LEFT JOIN Match_details m ON r.Safr_id=m.Safr_id
        LEFT JOIN Identity_Doc i ON r.Safr_id=i.Safr_id
        WHERE r.Full_name LIKE '%$search%' OR i.Doc_number LIKE '%$search%'
        LIMIT 20");
    while ($row = $q->fetch_assoc()) $results[] = $row;
}

// Pending searches
$pending = [];
$qp = $conn->query("SELECT sr.*, r.Full_name AS Searcher FROM Search_Req sr
    LEFT JOIN Refugee r ON sr.Safr_id=r.Safr_id
    ORDER BY sr.Status ASC LIMIT 30");
while ($row = $qp->fetch_assoc()) $pending[] = $row;

$conn->close();
include __DIR__ . '/../includes/header.php';
?>
<div class="page-header">
  <div class="container">
    <div class="hero-badge" style="margin-bottom:.75rem;">Module 06</div>
    <h1>Family Reunification</h1>
    <p>Find missing loved ones using names, SAFR IDs, or identity documents across the entire network.</p>
  </div>
</div>

<div class="section">
  <div class="container">
    <?php if ($msg): ?>
      <div class="alert <?= str_contains($msg,'Match found') ? 'alert-success' : 'alert-info' ?>" data-auto-dismiss><?= $msg ?></div>
    <?php endif; ?>

    <div class="tab-container" data-tabs>
      <div class="tabs">
        <button class="tab-btn active" data-tab="tab-search">Quick Search</button>
        <button class="tab-btn" data-tab="tab-formal">Submit Formal Request</button>
        <button class="tab-btn" data-tab="tab-pending">All Requests</button>
      </div>

      <!-- Quick Search -->
      <div class="tab-panel active" id="tab-search">
        <div class="card card-body fade-up" style="margin-bottom:2rem;">
          <h3 style="margin-bottom:1rem;">Search by Name or Document Number</h3>
          <form method="GET" style="display:flex;gap:1rem;flex-wrap:wrap;align-items:flex-end;">
            <div class="form-group" style="flex:1;min-width:240px;margin:0;">
              <label class="form-label">Name or Document Number</label>
              <input type="text" name="q" class="form-control" placeholder="e.g. Maria Hassan or P-123456"
                value="<?= htmlspecialchars($_GET['q'] ?? '') ?>">
            </div>
            <button type="submit" class="btn btn-primary">Search</button>
            <?php if ($search): ?><a href="<?= $basePath ?>/pages/family.php" class="btn btn-outline">Clear</a><?php endif; ?>
          </form>
        </div>

        <?php if ($search): ?>
          <?php if (empty($results)): ?>
            <div class="alert alert-info">No matching records found for "<strong><?= htmlspecialchars($search) ?></strong>".</div>
          <?php else: ?>
            <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:1.25rem;">
              <?php foreach ($results as $res): ?>
              <div class="card card-body fade-up">
                <div style="display:flex;align-items:center;gap:1rem;margin-bottom:1rem;">
                  <div style="width:48px;height:48px;border-radius:50%;background:linear-gradient(135deg,var(--amber),var(--gold));display:grid;place-items:center;font-weight:700;color:var(--brown-dark);font-size:1.1rem;flex-shrink:0;">
                    <?= strtoupper(substr($res['Full_name'],0,1)) ?>
                  </div>
                  <div>
                    <strong style="color:var(--brown-dark);font-size:1rem;"><?= htmlspecialchars($res['Full_name']) ?></strong><br>
                    <span class="badge badge-amber" style="font-size:.7rem;"><?= htmlspecialchars($res['Safr_id']) ?></span>
                  </div>
                </div>
                <div style="font-size:.85rem;color:var(--brown);display:grid;gap:.35rem;">
                  <div>🌍 <?= htmlspecialchars(($res['Country'] ?? '—').', '.($res['City'] ?? '—')) ?></div>
                  <div>🩸 Blood Group: <?= htmlspecialchars($res['Blood_Group'] ?? '—') ?></div>
                  <div>Camp: <?= htmlspecialchars($res['Camp_location'] ?? 'Unknown') ?></div>
                  <?php if ($res['Doc_type']): ?>
                  <div>Document: <?= htmlspecialchars($res['Doc_type']) ?> (<?= htmlspecialchars($res['Doc_number']) ?>)</div>
                  <?php endif; ?>
                </div>
              </div>
              <?php endforeach; ?>
            </div>
          <?php endif; ?>
        <?php endif; ?>
      </div>

      <!-- Formal Request -->
      <div class="tab-panel" id="tab-formal">
        <div class="card card-body" style="max-width:560px;">
          <h3 style="margin-bottom:0.5rem;">Submit a Formal Family Search Request</h3>
          <p style="font-size:.875rem;color:var(--brown);margin-bottom:1.5rem;">Your request will be cross-referenced across all SAFR camps. You will be notified when a match is found.</p>
          <form method="POST">
            <div class="form-group">
              <label class="form-label">Your SAFR ID</label>
              <input type="text" name="safr_id" class="form-control" placeholder="Your SAFR ID"
                value="<?= htmlspecialchars($_SESSION['user']['safr_id'] ?? '') ?>" required>
            </div>
            <div class="form-group">
              <label class="form-label">Full Name of Missing Person</label>
              <input type="text" name="missing_name" class="form-control" placeholder="As stated in their documents" required>
            </div>
            <div class="form-group">
              <label class="form-label">Document Number (if known)</label>
              <input type="text" name="doc_number" class="form-control" placeholder="Passport / ID number (optional)">
              <div class="form-hint">If you have their document number, matches will be more accurate.</div>
            </div>
            <button type="submit" name="submit_search" class="btn btn-primary btn-lg" style="width:100%;">Submit Search Request &rarr;</button>
          </form>
        </div>
      </div>

      <!-- All Requests -->
      <div class="tab-panel" id="tab-pending">
        <div class="table-wrapper">
          <table class="safr-table">
            <thead><tr><th>Searcher SAFR ID</th><th>Searcher Name</th><th>Looking For</th><th>Match Found</th><th>Status</th></tr></thead>
            <tbody>
              <?php if (empty($pending)): ?>
                <tr><td colspan="5" style="text-align:center;padding:2rem;">No search requests yet.</td></tr>
              <?php else: ?>
                <?php foreach ($pending as $p): ?>
                <tr>
                  <td><?= htmlspecialchars($p['Safr_id']) ?></td>
                  <td><?= htmlspecialchars($p['Searcher'] ?? '—') ?></td>
                  <td><?= htmlspecialchars($p['Missing_Name'] ?? '—') ?></td>
                  <td><?= $p['Match_Safr_id'] ? '<span class="badge badge-green">'.htmlspecialchars($p['Match_Safr_id']).'</span>' : '<span class="badge badge-gray">Not yet</span>' ?></td>
                  <td><?= $p['Status'] ? '<span class="badge badge-green">✓ Matched</span>' : '<span class="badge badge-amber">Searching</span>' ?></td>
                </tr>
                <?php endforeach; ?>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
