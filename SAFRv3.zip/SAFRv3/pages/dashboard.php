<?php
$pageTitle = 'Dashboard – SAFR';
require_once __DIR__ . '/../includes/session_check.php';
$conn = getDBConnection();
$user = $_SESSION['user'];
$role = $user['role'];
$name = $user['name'];

// Fetch role-specific stats
$stats = [];
if ($role === 'refugee') {
    $sid = $conn->real_escape_string($user['safr_id'] ?? '');
    $r = $conn->query("SELECT * FROM Refugee WHERE Safr_id='$sid'")->fetch_assoc();
    $evac = $conn->query("SELECT COUNT(*) AS c FROM Evac_Request WHERE Safr_id='$sid'")->fetch_assoc()['c'];
    $srch = $conn->query("SELECT COUNT(*) AS c FROM Search_Req WHERE Safr_id='$sid'")->fetch_assoc()['c'];
    $camp = $conn->query("SELECT Camp_id FROM Refugee_Stay_in_Camp WHERE Safr_id='$sid' ORDER BY Arrival_date DESC LIMIT 1")->fetch_assoc();
} elseif ($role === 'volunteer') {
    $vid = $conn->real_escape_string($user['volunteer_id'] ?? '');
    $assignments = $conn->query("SELECT COUNT(*) AS c FROM Assignment WHERE Volunteer_id='$vid'")->fetch_assoc()['c'];
} elseif ($role === 'ngo') {
    $ngo = $conn->real_escape_string($name);
    $camps_count = $conn->query("SELECT COUNT(*) AS c FROM Camp_Request WHERE NGO_name='$ngo'")->fetch_assoc()['c'];
    $inv_count   = $conn->query("SELECT COUNT(*) AS c FROM NGO_Inventory WHERE NGO_name='$ngo'")->fetch_assoc()['c'];
    $donors_count= $conn->query("SELECT COUNT(*) AS c FROM Donor_NGO WHERE NGO_name='$ngo'")->fetch_assoc()['c'];
} elseif ($role === 'donor') {
    $dn = $conn->real_escape_string($name);
    $donor = $conn->query("SELECT * FROM Donor WHERE Name='$dn'")->fetch_assoc();
    $ngo_links = $conn->query("SELECT NGO_name FROM Donor_NGO WHERE Donor_Name='$dn'");
}
$conn->close();
include __DIR__ . '/../includes/header.php';
?>
<div class="dash-layout">
  <aside class="sidebar">
    <div class="sidebar-header">
      <div class="sidebar-user">
        <div class="sidebar-avatar"><?= strtoupper(substr($name,0,1)) ?></div>
        <div class="sidebar-user-info">
          <strong><?= htmlspecialchars($name) ?></strong>
          <span><?= ucfirst($role) ?></span>
        </div>
      </div>
    </div>
    <ul class="sidebar-nav">
      <li class="sidebar-section-label">Main</li>
      <li><a href="<?= $basePath ?>/pages/dashboard.php" class="active"><span class="nav-icon">Dashboard</span></a></li>

      <?php if ($role === 'refugee'): ?>
        <li><a href="<?= $basePath ?>/pages/refugee.php"><span class="nav-icon">Profile</span></a></li>
        <li><a href="<?= $basePath ?>/pages/evacuation.php"><span class="nav-icon">Evacuation</span></a></li>
        <li><a href="<?= $basePath ?>/pages/family.php"><span class="nav-icon">Family</span></a></li>

      <?php elseif ($role === 'volunteer'): ?>
        <li><a href="<?= $basePath ?>/pages/volunteer.php"><span class="nav-icon">Assignments</span></a></li>
        <li><a href="<?= $basePath ?>/pages/medical.php"><span class="nav-icon">Medical</span></a></li>

      <?php elseif ($role === 'ngo'): ?>
        <li><a href="<?= $basePath ?>/pages/aid.php"><span class="nav-icon">Aid</span></a></li>
        <li><a href="<?= $basePath ?>/pages/medical.php"><span class="nav-icon">Medical</span></a></li>
        <li><a href="<?= $basePath ?>/pages/volunteer.php"><span class="nav-icon">Volunteers</span></a></li>

      <?php elseif ($role === 'donor'): ?>
        <li><a href="<?= $basePath ?>/pages/donate.php"><span class="nav-icon">Donate</span></a></li>
      <?php endif; ?>

      <li class="sidebar-section-label">Explore</li>
      <li><a href="<?= $basePath ?>/pages/family.php"><span class="nav-icon">Search</span></a></li>
      <li><a href="<?= $basePath ?>/pages/donate.php"><span class="nav-icon">Donate</span></a></li>
      <li class="sidebar-section-label">Account</li>
      <li><a href="<?= $basePath ?>/auth/logout.php"><span class="nav-icon">Logout</span></a></li>
    </ul>
  </aside>

  <main class="dash-main">
    <div class="dash-topbar">
      <h1>Good <?= (date('H')<12?'Morning':(date('H')<17?'Afternoon':'Evening')) ?>, <?= htmlspecialchars(explode(' ',$name)[0]) ?></h1>
    </div>

    <?php if ($role === 'refugee'): ?>
      <div class="stat-grid">
        <div class="stat-card"><div class="stat-icon amber">ID</div><div><div class="stat-value" style="font-size:1rem;"><?= htmlspecialchars($user['safr_id'] ?? 'N/A') ?></div><div class="stat-label">SAFR ID</div></div></div>
        <div class="stat-card"><div class="stat-icon gold">Camp</div><div><div class="stat-value"><?= htmlspecialchars($camp['Camp_id'] ?? 'None') ?></div><div class="stat-label">Current Camp</div></div></div>
        <div class="stat-card"><div class="stat-icon brown">E</div><div><div class="stat-value"><?= $evac ?></div><div class="stat-label">Evac Requests</div></div></div>
        <div class="stat-card"><div class="stat-icon dark">S</div><div><div class="stat-value"><?= $srch ?></div><div class="stat-label">Family Searches</div></div></div>
      </div>
      <div class="card card-body fade-up">
        <h3 style="margin-bottom:1rem;color:var(--brown-dark);">Refugee Information</h3>
        <div class="form-row">
          <div><strong>Name:</strong> <?= htmlspecialchars($r['Full_name'] ?? '') ?></div>
          <div><strong>Blood Group:</strong> <?= htmlspecialchars($r['Blood_Group'] ?? 'N/A') ?></div>
          <div><strong>Country:</strong> <?= htmlspecialchars($r['Country'] ?? 'N/A') ?></div>
          <div><strong>City:</strong> <?= htmlspecialchars($r['City'] ?? 'N/A') ?></div>
          <div><strong>DOB:</strong> <?= htmlspecialchars($r['Date_of_Birth'] ?? 'N/A') ?></div>
          <div><strong>Reg Date:</strong> <?= htmlspecialchars($r['Reg_date'] ?? 'N/A') ?></div>
        </div>
        <div style="margin-top:1.5rem;display:flex;gap:1rem;flex-wrap:wrap;">
          <a href="<?= $basePath ?>/pages/evacuation.php" class="btn btn-primary">Request Evacuation</a>
          <a href="<?= $basePath ?>/pages/family.php" class="btn btn-outline">Find Family</a>
        </div>
      </div>

    <?php elseif ($role === 'volunteer'): ?>
      <div class="stat-grid">
        <div class="stat-card"><div class="stat-icon amber">📋</div><div><div class="stat-value"><?= $assignments ?></div><div class="stat-label">Total Assignments</div></div></div>
        <div class="stat-card"><div class="stat-icon gold">🆔</div><div><div class="stat-value" style="font-size:0.95rem;"><?= htmlspecialchars($user['volunteer_id'] ?? '') ?></div><div class="stat-label">Volunteer ID</div></div></div>
      </div>
      <div class="card card-body fade-up">
        <h3 style="margin-bottom:1rem;">Quick Actions</h3>
        <div style="display:flex;gap:1rem;flex-wrap:wrap;">
          <a href="<?= $basePath ?>/pages/volunteer.php" class="btn btn-primary">View Assignments</a>
          <a href="<?= $basePath ?>/pages/medical.php" class="btn btn-outline">Medical Inventory</a>
        </div>
      </div>

    <?php elseif ($role === 'ngo'): ?>
      <div class="stat-grid">
        <div class="stat-card"><div class="stat-icon amber">A</div><div><div class="stat-value"><?= $camps_count ?></div><div class="stat-label">Camp Requests</div></div></div>
        <div class="stat-card"><div class="stat-icon gold">I</div><div><div class="stat-value"><?= $inv_count ?></div><div class="stat-label">Inventory Items</div></div></div>
        <div class="stat-card"><div class="stat-icon brown">D</div><div><div class="stat-value"><?= $donors_count ?></div><div class="stat-label">Linked Donors</div></div></div>
      </div>
      <div class="card card-body fade-up">
        <h3 style="margin-bottom:1rem;">Quick Actions</h3>
        <div style="display:flex;gap:1rem;flex-wrap:wrap;">
          <a href="<?= $basePath ?>/pages/aid.php" class="btn btn-primary">Manage Aid</a>
          <a href="<?= $basePath ?>/pages/medical.php" class="btn btn-outline">Medical Resources</a>
          <a href="<?= $basePath ?>/pages/volunteer.php" class="btn btn-outline">Volunteer Matching</a>
        </div>
      </div>

    <?php elseif ($role === 'donor'): ?>
      <div class="stat-grid">
        <div class="stat-card"><div class="stat-icon amber">💰</div><div><div class="stat-value">$<?= number_format($donor['Total_Amount'] ?? 0, 2) ?></div><div class="stat-label">Total Donated</div></div></div>
        <div class="stat-card"><div class="stat-icon gold">🔁</div><div><div class="stat-value"><?= htmlspecialchars(ucfirst($donor['Donor_type'] ?? 'N/A')) ?></div><div class="stat-label">Donor Type</div></div></div>
      </div>
      <div class="card card-body fade-up">
        <h3 style="margin-bottom:1rem;">Make an Impact</h3>
        <a href="<?= $basePath ?>/pages/donate.php" class="btn btn-primary">Donate Now &rarr;</a>
      </div>
    <?php endif; ?>
  </main>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
