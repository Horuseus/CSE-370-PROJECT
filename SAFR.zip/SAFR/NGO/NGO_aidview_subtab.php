<html lang="en">
  <head>
      <meta charset="utf-8"/>
      <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
      <meta name="description" content="About the site"/>
      <meta name="author" content="Author name"/>
      <title> show_NGO </title>
    
      <!-- core CSS -->
      <link href="../css/bootstrap.min.css" rel="stylesheet"/>
      <link href="../css/font-awesome.min.css" rel="stylesheet"/>
      <link href="../css/animate.min.css" rel="stylesheet"/>
      <link href="../css/main.css" rel="stylesheet"/> 
  </head>

  <body> 
    <!-- following section is used for creating the menubar in the webpage -->
	<section id="header">
		<div class="row">  
			<div class="col-md-2" style="font-size: 30px;color:#F2674A;"> <a href="NGO_Dashboard.php">SAFR</a></div>
			<div class="col-md-2" style="font-size: 20px;color:#F2674A; text-align:right"> <a href="update_inventory.php">Update inventory</a> </div>
		</div>
	</section>
	
	<section id = "section1">
		<div class="title"> All aid available </div>
		<div style="margin-left:10%; margin-right:10%; margin-top:50px; margin-bottom:50px;text-align:center;background:#66b3ff;">
			<div class="row" style="padding:5px;"> 
				<div class="col-md-3">  NGO_name </div>
				<div class="col-md-3">  item_name </div>
				<div class="col-md-3">  category </div>
				<div class="col-md-3">  unit </div>
				
				
		
			</div>
			
			<!-- here we will write php codes to fetch data from database and will show in the rows of this table -->
			
			<?php 
			//session_start();
			include('../dbconnect.php');
            session_start();
			$ngo_name =$_SESSION['NGO_name'];
			$sql = "SELECT * FROM ngo_inventory where NGO_name = '$ngo_name'";
			$result = mysqli_query($conn, $sql);
			if(mysqli_num_rows($result) > 0){
				//here we will print every row that is returned by our query $sql
				while($row = mysqli_fetch_array($result)){
				//here we have to write some HTML code, so we will close php tag
			?>
			<div class="row" style="padding:5px;"> 
				<div class="col-md-3">  <?php echo $row[0]; ?> </div>
				<div class="col-md-3">  <?php echo $row[1]; ?> </div>
				<div class="col-md-3">  <?php echo $row[2]; ?> </div>
				<div class="col-md-3">  <?php echo $row[3]; ?> </div>
				
				
				
			</div>
			
			<?php 
				}					
			}
			?>
			
		</div>
		
		
		
		
		
	</section>

	
	<!----- Footer ----->
	<section id="footer"> 
	
	</section>
    <script src="js/jquery.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.isotope.min.js"></script>
    <script src="js/wow.min.js"></script>
  </body> 
</html>

