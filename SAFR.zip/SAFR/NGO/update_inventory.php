<?php
    session_start();
    include('../dbconnect.php');
    $ngo_name = $_SESSION['NGO_name'];

    if(isset($_POST['item']) && isset($_POST['unit']) && isset($_POST['cate'])){
        $u = $_POST['item'];
        $s = $_POST['unit'];
        $c = $_POST['cate'];

        $sql = "INSERT INTO ngo_inventory VALUES ('$ngo_name', '$u', '$c', '$s')";
        $result = mysqli_query($conn,$sql);

        if(mysqli_affected_rows($conn)){
            header('location: NGO_aidview_subtab.php');
        }
        else{
            echo "do it again";
            header('location: update_inventory.php');
        }
    }
?>

<html lang="en">
  <head>
      <meta charset="utf-8"/>
      <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
      <title> SAFR_NGO </title>
      <link href="../css/bootstrap.min.css" rel="stylesheet"/>
      <link href="../css/font-awesome.min.css" rel="stylesheet"/>
      <link href="../css/animate.min.css" rel="stylesheet"/>
      <link href="../css/main.css" rel="stylesheet"/> 
  </head>
  <body>
    <section id="header">
        <div class="row">  
            <div class="col-md-2" style="font-size: 30px;color:#F2674A;"> <a href="NGO_Dashboard.php">SAFR</a></div>
            <div class="col-md-2" style="font-size: 30px;color:#F2674A; text-align:right"> <a href="NGO_aidview_subtab.php">Inventory</a> </div>
        </div>
    </section>

    <section id="section1">
        <div class="title"> Add Aid </div>

        <form action="update_inventory.php" method="post" class="form_design">
            NGO Name: <input type="text" name="name" value="<?php echo $ngo_name ?>" readonly> <br/><br>
            Item Name: <input type="text" name="item" required> <br/><br>
            Item Category:
            <select name="cate" required>
                <option value="" disabled selected>-- Select Category --</option>
                <option value="Food">Food</option>
                <option value="Shelter">Shelter</option>
                <option value="Medical">Medical</option>
                <option value="Sanitation">Sanitation</option>
            </select>
            <br><br>
            Item Unit: <input type="number" name="unit" required> <br/><br>
            <input type="submit" value="Add Items">
        </form>
    </section>

    <section id="footer"></section>
    <script src="../js/jquery.js"></script>
    <script src="../js/bootstrap.min.js"></script>
    <script src="../js/jquery.isotope.min.js"></script>
    <script src="../js/wow.min.js"></script>
  </body>
</html>