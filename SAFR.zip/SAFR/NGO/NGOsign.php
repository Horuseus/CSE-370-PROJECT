<html lang="en">
  <head>
      <meta charset="utf-8"/>
      <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
      <meta name="description" content="About the site"/>
      <meta name="author" content="Author name"/>
      <title> NGO signing</title>
    
      <!-- core CSS -->
      <link href="../css/bootstrap.min.css" rel="stylesheet"/>
      <link href="../css/font-awesome.min.css" rel="stylesheet"/>
      <link href="../css/animate.min.css" rel="stylesheet"/>
      <link href="../css/main.css" rel="stylesheet"/> 
  </head>

  <body> 
    <!-- following section is used for creating the menubar in the webpage -->
	<section id="header">
		<div class="row">  
			<div class="col-md-2" style="font-size: 30px;color:#F2674A;"> SAFR </div>
			<div class="col-md-10" style="text-align: right"> 
				<a href="../Volunteer/Volunteer_signin.php" style="margin-left: 20px;"> Volunteer </a>
			</div>
		</div>
	</section>
	
	<section id = "section1">
		<div class="title"> NGO SIGN IN </div>
		
		<form action="NGO_signin.php" class="form_design" method="post">
			UseID: <input type="text" name="ID" required> <br/>
			Password: <input type="password" name="pass" required> <br/> <br/>
			<input type="submit" value="Sign In">
		</form>		
	</section>

	<section id = "sign up">
        <div class="title"> Add an NGO</div>
        <a href="add_NGO.php">
            <input type="submit" value = "Sign UP	">
        </a>
    </section>

	
	<!----- Footer ----->
	<section id="footer"> 
	
	</section>
    <script src="../js/jquery.js"></script>
    <script src="../js/bootstrap.min.js"></script>
    <script src="../js/jquery.isotope.min.js"></script>
    <script src="../js/wow.min.js"></script>
  </body> 
</html>

