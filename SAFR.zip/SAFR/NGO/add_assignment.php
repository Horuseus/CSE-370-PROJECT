<?php
// add this to see what's in the session

                  
 session_start();
  include('../dbconnect.php');
  
  if(!isset($_SESSION['NGO_name'])){
    header('location:NGOsign.php');
  }

  $ngo_name =$_SESSION['NGO_name'];
  
  $sql= "SELECT Assignment_ID FROM assignment_required_skill ORDER BY Assignment_ID DESC LIMIT 1";
  $result = mysqli_query($conn, $sql);
  $row = mysqli_fetch_assoc($result);
  $lastID = $row['Assignment_ID'];
  $num = filter_var($lastID, FILTER_SANITIZE_NUMBER_INT) + 1;
  $assingmentID= "ASGN0".$num;
  

  $sql = "SELECT Camp_id FROM ngo WHERE NGO_name='$ngo_name'";
  $result = mysqli_query($conn, $sql);
  $row = mysqli_fetch_assoc($result);
  $camp_id= $row['Camp_id'];

  $date = date("Y-m-d");



?>





<html lang="en">
  <head>
      <meta charset="utf-8"/>
      <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
      <meta name="description" content="About the site"/>
      <meta name="author" content="Author name"/>
      <title> SAFR_NGO </title>
    
      <!-- core CSS -->
      <link href="../css/bootstrap.min.css" rel="stylesheet"/>
      <link href="../css/font-awesome.min.css" rel="stylesheet"/>
      <link href="../css/animate.min.css" rel="stylesheet"/>
      <link href="../css/main.css" rel="stylesheet"/> 
  </head>

  <body> 
    <!-- following section is used for creating the menubar in the webpage -->
	<section id="header">
		<div class="row">  
			<div class="col-md-2" style="font-size: 30px;color:#F2674A;"> SAFR </div>
      <div class="col-md-10" style="text-align: right"><a href="assignments.php"> View Assignments </a>
		</div>
	</section>
	
	<section id = "section1">
		<div class="title"> assign an assignment to a volunteer  </div>
		
		<form action="add_assign.php" class="form_design" method="post">
			
			Assignment ID: <input type="text" name="aid" value="<?php echo $assingmentID ?>" readonly> <br/> 
			Assignment_skill: <br> <br>
      <select name="skill" required>
        <option value="" disabled selected>-- Select Required Skill --</option>
        <option value="Education">Education</option>
        <option value="Distribution">Distribution</option>
        <option value="Counselling">Counselling</option>
        <option value="Mechanic">Mechanic</option>
        <option value="Logistics">Logistics</option>
        <option value="Translation">Translation</option>
        <option value="Medical Worker">Medical Worker</option>
      </select>
      <br><br>

			Camp_id: <input type="text" name="cid" value="<?php echo $camp_id ?>" readonly> <br/>
			Assigned date: <input type="text" name="date" value="<?php echo $date ?> " readonly> <br/>
			
			
			
			<br/>
			<input type="submit" value="next">
		</form>
	</section>

	
	<!----- Footer ----->
	<section id="footer"> 
	
	</section>
    <script src="../js/jquery.js"></script>
    <script src="../js/bootstrap.min.js"></script>
    <script src="../js/jquery.isotope.min.js"></script>
    <script src="../js/wow.min.js"></script>
  </body> 
</html>



