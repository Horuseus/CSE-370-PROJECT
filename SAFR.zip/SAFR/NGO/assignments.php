<?php
    session_start();
    include('../dbconnect.php');

    $sql = "SELECT a.Assignment_ID, a.Volunteer_id, a.Assigned_Date, a.Camp_id, vq.Outcome 
            FROM assignment a 
            LEFT JOIN volunteers_quota vq ON a.Volunteer_id = vq.Volunteer_id";
    $result = mysqli_query($conn,$sql);
?>

<html lang="en">
  <head>
      <meta charset="utf-8"/>
      <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
      <title> SAFR_NGO </title>
      <link href="../css/bootstrap.min.css" rel="stylesheet"/>
      <link href="../css/font-awesome.min.css" rel="stylesheet"/>
      <link href="../css/animate.min.css" rel="stylesheet"/>
      <link href="../css/main.css" rel="stylesheet"/> 
  </head>
  <body>
    <section id="header">
        <div class="row">  
            <div class="col-md-2" style="font-size: 30px;color:#F2674A;"> SAFR </div>
            <div class="col-md-10" style="text-align: right">
                <a href="add_assignment.php"> Create Assignment </a> | 
                <a href="NGO_outcome_leaftab.php"> View Outcomes </a>
            </div>
        </div>
    </section>

    <section id="section1">
        <div class="title"> All Assignments </div>
        <div style="margin-left:10%; margin-right:10%; margin-top:50px; margin-bottom:50px;text-align:center;background:#66b3ff;">
            
            <div class="row" style="padding:5px; font-weight:bold;">
                <div class="col-md-2"> Assignment ID </div>
                <div class="col-md-2"> Volunteer ID </div>
                <div class="col-md-3"> Assigned Date </div>
                <div class="col-md-2"> Camp ID </div>
                <div class="col-md-3"> Status </div>
            </div>

            <?php
            if(mysqli_num_rows($result) > 0){
                while($row = mysqli_fetch_assoc($result)){
                    $status = (!empty($row['Outcome'])) ? "Done" : "Pending";
            ?>
            <div class="row" style="padding:5px;">
                <div class="col-md-2"> <?php echo $row['Assignment_ID']; ?> </div>
                <div class="col-md-2"> <?php echo $row['Volunteer_id']; ?> </div>
                <div class="col-md-3"> <?php echo $row['Assigned_Date']; ?> </div>
                <div class="col-md-2"> <?php echo $row['Camp_id']; ?> </div>
                <div class="col-md-3"> <?php echo $status; ?> </div>
            </div>
            <?php
                }
            } else {
                echo "<p>No assignments found</p>";
            }
            ?>

        </div>
    </section>

    <section id="footer"></section>
    <script src="../js/jquery.js"></script>
    <script src="../js/bootstrap.min.js"></script>
    <script src="../js/jquery.isotope.min.js"></script>
    <script src="../js/wow.min.js"></script>
  </body>
</html>