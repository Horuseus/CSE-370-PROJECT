<?php 
	include('../dbconnect.php');
            session_start();
			$ngo_name =$_SESSION['NGO_name'];

if( isset($_POST['camp']) && isset($_POST['item']) && isset($_POST['amount'])){

    
    $camp = $_POST['camp'];   // not used in query but kept
    $item = $_POST['item'];
    $amount = $_POST['amount'];

    // Step 1: Get current Unit
    $sql = "SELECT Unit FROM ngo_inventory 
            WHERE NGO_name='$ngo_name' AND Item_name='$item'";

    $result = mysqli_query($conn, $sql);

    if($result && mysqli_num_rows($result) > 0){

        $row = mysqli_fetch_assoc($result);
        $current_unit = $row['Unit'];

        // Step 2: Check if enough stock exists
        if($current_unit >= $amount){

            $new_unit = $current_unit - $amount;

            // Step 3: Update the database
            $update_sql = "UPDATE ngo_inventory 
                           SET Unit = '$new_unit' 
                           WHERE NGO_name='$ngo_name' AND Item_name='$item'";

            if(mysqli_query($conn, $update_sql)){
                echo "<h3>Request Accepted </h3>";
                
            } else {
                echo "Error updating data: " . mysqli_error($conn);
            }

        } else {
            echo "<h3>Not enough inventory </h3>";
        }

    } else {
        echo "<h3>No matching record found </h3>";
    }
}
?>
<html lang="en">
  <head>
      <meta charset="utf-8"/>
      <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
      <meta name="description" content="About the site"/>
      <meta name="author" content="Author name"/>
      <title> show_NGO </title>
    
      <!-- core CSS -->
      <link href="../css/bootstrap.min.css" rel="stylesheet"/>
      <link href="../css/font-awesome.min.css" rel="stylesheet"/>
      <link href="../css/animate.min.css" rel="stylesheet"/>
      <link href="../css/main.css" rel="stylesheet"/> 
  </head>

  <body> 
    <!-- following section is used for creating the menubar in the webpage -->
	<section id="header">
		<div class="row">  
			<div class="col-md-2" style="font-size: 30px;color:#F2674A;"> <a href="NGO_Dashboard.php">SAFR</a></div>
		</div>
	</section>
	
	<section id = "section1">
		<div class="title"> request info  </div>
		
		<form action="reqaccepttab.php" class="form_design" method="post">
			
			your ngo: <input type="text" name="ngo" value = "<?php echo $ngo_name ?> " readonly> <br/> 
			camp: <input type="text" name="camp"> <br/>
			item_name: <input type="text" name="item"> <br/>
			amount: <input type="text" name="amount"> <br/>
			
			
			
			
			<br/>
			<input type="submit" value="done">
		</form>
	</section>
	

	

	
	<!----- Footer ----->
	<section id="footer"> 
	
	</section>
    <script src="../js/jquery.js"></script>
    <script src="../js/bootstrap.min.js"></script>
    <script src="../js/jquery.isotope.min.js"></script>
    <script src="../js/wow.min.js"></script>
  </body> 
</html>

