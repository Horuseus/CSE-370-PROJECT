<?php
include('../dbconnect.php');
session_start();
$ngo_name =$_SESSION['NGO_name'];
$date = date("Y-m-d");

$sql = "SELECT er.*, c.Camp_id, n.NGO_name 
FROM evac_request er
JOIN camp c 
    ON er.Operating_areas = c.Location
JOIN ngo n 
    ON c.Camp_id = n.Camp_id
WHERE n.NGO_name = '$ngo_name' AND er.Status='0'";

$result2 = mysqli_query($conn,$sql);

if(isset($_POST['evacid'])){
    $e=$_POST['evacid'];
    $s=1;
    $d = $date;

    $sql= "UPDATE evac_request SET Status='$s', Allocation_date='$d' WHERE Evareq_id='$e'";
    $result = mysqli_query($conn,$sql);

    if(mysqli_affected_rows($conn)>0){
    echo "request recorded";

    header('Refresh:1; url=Show_evacs.php');
    //exit();
}
}
?>

<html lang="en">
<head>
    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>Evac Requests</title>
 
    <link href="../css/bootstrap.min.css" rel="stylesheet"/>
    <link href="../css/font-awesome.min.css" rel="stylesheet"/>
    <link href="../css/animate.min.css" rel="stylesheet"/>
    <link href="../css/main.css" rel="stylesheet"/>
</head>
 
<body>
 
    <section id="header">
        <div class="row">
            <div class="col-md-2" style="font-size: 30px;color:#F2674A;"> <a href="NGO_Dashboard.php">SAFR</a></div>
            <div class="col-md-10" style="text-align: right">
                <a href="NGO_Assignment_subtab.php"> Assignment </a>
                <a href="NGO_aidview_subtab.php" style="margin-left: 20px;"> Aid View </a>
                <a href="NGO_Campreqsubtab.php" style="margin-left: 20px;"> Camp Req </a>
                <a href="Show_evacs.php" style="margin-left: 20px;"> Evacuation Requests </a>
                <a href="../logout.php" style="margin-left: 20px;"> Logout </a>
            </div>
        </div>
    </section>
 
    <section id="section1">
        <h2>Accept Evacuation Request</h2>
        <form action="Show_evacs.php" method="post">
            Evacuation Request ID:
            <select name="evacid" required>
                <?php while($row = mysqli_fetch_assoc($result2)){ ?>
                <option value="<?php echo $row['Evareq_id']; ?>">
                    <?php echo $row['Evareq_id']."-".$row['Priority']; ?>
                </option>
                <?php }?>
            </select>
            <br><br>
            <b>Allocation Date:</b>
            <input type="date" value="<?php echo $date ?>" readonly>
            <br><br>
            <input type="submit" value="Accept Evacuation Request">
        </form>
    </section>
 
    <section id="footer"></section>
 
    <script src="../js/jquery.js"></script>
    <script src="../js/bootstrap.min.js"></script>
    <script src="../js/jquery.isotope.min.js"></script>
    <script src="../js/wow.min.js"></script>
 
</body>
</html>