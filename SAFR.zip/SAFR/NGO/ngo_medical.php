<?php
session_start();
include('../dbconnect.php');

if(!isset($_SESSION['NGO_name'])){
    header('location:NGOsign.php');
}

$ngo_name = $_SESSION['NGO_name'];

$sql = "SELECT Camp_id FROM ngo WHERE NGO_name='$ngo_name'";
$result = mysqli_query($conn, $sql);
$row = mysqli_fetch_assoc($result);
$camp_id = $row['Camp_id'];

if(isset($_POST['requested_inv']) && isset($_POST['units'])){
    $requested_inv = $_POST['requested_inv'];
    $units = $_POST['units'];

    $get_item_sql = "SELECT Item_name FROM camp_medical_inventory WHERE Inventory_id='$requested_inv'";
    $get_item_result = mysqli_query($conn, $get_item_sql);
    
    if($get_item_result && mysqli_num_rows($get_item_result) > 0){
        $item_row = mysqli_fetch_assoc($get_item_result);
        $item_needed = $item_row['Item_name'];
        
        // Get a requesting inventory from this camp (use the first one, or you can modify logic)
        $get_requesting_sql = "SELECT Inventory_id FROM camp_medical_inventory WHERE Camp_id='$camp_id' LIMIT 1";
        $get_requesting_result = mysqli_query($conn, $get_requesting_sql);
        
        if($get_requesting_result && mysqli_num_rows($get_requesting_result) > 0){
            $requesting_row = mysqli_fetch_assoc($get_requesting_result);
            $requesting_inv = $requesting_row['Inventory_id'];
            
            $insert_sql = "INSERT INTO camp_medical_inventory_asks_for (Requesting_Inventory_id, Requested_Inventory_id, Item_needed, Units, Status) 
                           VALUES ('$requesting_inv', '$requested_inv', '$item_needed', '$units', 0)";
            
            if(mysqli_query($conn, $insert_sql)){
                $success_msg = "Medical request created successfully!";
            } else {
                $error_msg = "Failed to create request: " . mysqli_error($conn);
            }
        } else {
            $error_msg = "No inventory found for your camp. Please contact administrator.";
        }
    } else {
        $error_msg = "Invalid inventory selected.";
    }
}

$inventory_sql = "SELECT Inventory_id, Item_name FROM camp_medical_inventory WHERE Camp_id='$camp_id'";
$inventory_result = mysqli_query($conn, $inventory_sql);

$other_inventory_sql = "SELECT Inventory_id, Item_name, Camp_id FROM camp_medical_inventory";
$other_inventory_result = mysqli_query($conn, $other_inventory_sql);

// Get pending medical requests for this camp
$pending_sql = "SELECT cmia.*, cmi1.Camp_id as Requesting_Camp, cmi2.Camp_id as Requested_Camp 
                FROM camp_medical_inventory_asks_for cmia
                JOIN camp_medical_inventory cmi1 ON cmia.Requesting_Inventory_id = cmi1.Inventory_id
                JOIN camp_medical_inventory cmi2 ON cmia.Requested_Inventory_id = cmi2.Inventory_id
                WHERE cmi1.Camp_id = '$camp_id' AND cmia.Status = 0";
$pending_result = mysqli_query($conn, $pending_sql);

$accepted_sql = "SELECT cmia.*, cmi1.Camp_id as Requesting_Camp, cmi2.Camp_id as Requested_Camp 
                FROM camp_medical_inventory_asks_for cmia
                JOIN camp_medical_inventory cmi1 ON cmia.Requesting_Inventory_id = cmi1.Inventory_id
                JOIN camp_medical_inventory cmi2 ON cmia.Requested_Inventory_id = cmi2.Inventory_id
                WHERE cmi1.Camp_id = '$camp_id' AND cmia.Status = 1";
$accepted_result = mysqli_query($conn, $accepted_sql);
?>

<html lang="en">
  <head>
      <meta charset="utf-8"/>
      <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
      <meta name="description" content="About the site"/>
      <meta name="author" content="Author name"/>
      <title> SAFR_NGO - Medical Requests </title>
    
      <!-- core CSS -->
      <link href="../css/bootstrap.min.css" rel="stylesheet"/>
      <link href="../css/font-awesome.min.css" rel="stylesheet"/>
      <link href="../css/animate.min.css" rel="stylesheet"/>
      <link href="../css/main.css" rel="stylesheet"/> 
  </head>

  <body> 

	<section id="header">
		<div class="row">  
			<div class="col-md-2" style="font-size: 30px;color:#F2674A;"> SAFR </div>
			<div class="col-md-10" style="text-align: right"> 
				<a href="NGO_Dashboard.php"> Dashboard </a> 
				<a href="NGO_Campreqsubtab.php" style="margin-left: 20px;"> Camp Requests </a> 
			</div>
		</div>
	</section>
	
	<section id = "section1">
		<div class="title"> Create Medical Supply Request </div>
		
		<?php if(isset($success_msg)){ ?>
			<div style="color: green; text-align: center; margin: 20px;">
				<?php echo $success_msg; ?>
			</div>
		<?php } ?>
		
		<?php if(isset($error_msg)){ ?>
			<div style="color: red; text-align: center; margin: 20px;">
				<?php echo $error_msg; ?>
			</div>
		<?php } ?>
		
		<form action="ngo_medical.php" class="form_design" method="post">
			
			Your Camp: <input type="text" name="your_camp" value="<?php echo $camp_id ?>" readonly> <br/><br/>
			
			Request From (Camp Inventory): <br><br>
			<select name="requested_inv" required>
				<option value="" disabled selected>-- Select Inventory --</option>
				<?php 
					while($other_inv = mysqli_fetch_assoc($other_inventory_result)){ 
				?>
					<option value="<?php echo $other_inv['Inventory_id']; ?>">
						<?php echo $other_inv['Inventory_id'] . " - " . $other_inv['Item_name'] . " (Camp: " . $other_inv['Camp_id'] . ")"; ?>
					</option>
				<?php } ?>
			</select>
			<br><br>
			
			Units Required: <input type="number" name="units" min="1" required> <br/><br/>
			
			<input type="submit" value="Create Request">
		</form>
	</section>

	<section id = "section2">
		<div class="title"> Pending Medical Requests </div>
		<div style="margin-left:10%; margin-right:10%; margin-top:50px; margin-bottom:50px;text-align:center;background:#FFD700;">
			<div class="row" style="padding:5px; font-weight:bold;"> 
				<div class="col-md-2"> Requesting Inv ID </div>
				<div class="col-md-2"> Requested Inv ID </div>
				<div class="col-md-2"> Item Needed </div>
				<div class="col-md-2"> Units </div>
				<div class="col-md-2"> Requesting From Camp </div>
				<div class="col-md-2"> Status </div>
			</div>
			
			<?php 
			if(mysqli_num_rows($pending_result) > 0){
				while($row = mysqli_fetch_array($pending_result)){
			?>
			<div class="row" style="padding:5px;"> 
				<div class="col-md-2"> <?php echo $row['Requesting_Inventory_id']; ?> </div>
				<div class="col-md-2"> <?php echo $row['Requested_Inventory_id']; ?> </div>
				<div class="col-md-2"> <?php echo $row['Item_needed']; ?> </div>
				<div class="col-md-2"> <?php echo $row['Units']; ?> </div>
				<div class="col-md-2"> <?php echo $row['Requested_Camp']; ?> </div>
				<div class="col-md-2"> Pending </div>
			</div>
			
			<?php 
				}					
			} else {
			?>
			<div class="row" style="padding:10px;">
				<div class="col-md-12">No pending medical requests</div>
			</div>
			<?php
			}
			?>
			
		</div>
	</section>

	<section id = "section3">
    <div class="title"> Accepted Medical Requests </div>
    <div style="margin-left:10%; margin-right:10%; margin-top:50px; margin-bottom:50px;text-align:center;background:#90EE90;">
        <div class="row" style="padding:5px; font-weight:bold;"> 
            <div class="col-md-2"> Requesting Inv ID </div>
            <div class="col-md-2"> Requested Inv ID </div>
            <div class="col-md-2"> Item Needed </div>
            <div class="col-md-2"> Units </div>
            <div class="col-md-2"> Requesting From Camp </div>
            <div class="col-md-2"> Status </div>
        </div>
        
        <?php 
        if(mysqli_num_rows($accepted_result) > 0){
            while($row = mysqli_fetch_array($accepted_result)){
        ?>
        <div class="row" style="padding:5px;"> 
            <div class="col-md-2"> <?php echo $row['Requesting_Inventory_id']; ?> </div>
            <div class="col-md-2"> <?php echo $row['Requested_Inventory_id']; ?> </div>
            <div class="col-md-2"> <?php echo $row['Item_needed']; ?> </div>
            <div class="col-md-2"> <?php echo $row['Units']; ?> </div>
            <div class="col-md-2"> <?php echo $row['Requested_Camp']; ?> </div>
            <div class="col-md-2"> Accepted </div>
        </div>
        
        <?php 
            }					
        } else {
        ?>
        <div class="row" style="padding:10px;">
            <div class="col-md-12">No accepted medical requests</div>
        </div>
        <?php
        }
        ?>
        
    </div>
</section>

	
	<!----- Footer ----->
	<section id="footer"> 
	
	</section>
    <script src="../js/jquery.js"></script>
    <script src="../js/bootstrap.min.js"></script>
    <script src="../js/jquery.isotope.min.js"></script>
    <script src="../js/wow.min.js"></script>
  </body> 
</html>
