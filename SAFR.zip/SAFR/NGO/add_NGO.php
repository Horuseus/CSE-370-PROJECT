<?php
// first of all, we need to connect to the database
require_once('../dbconnect.php');


$sql1= "SELECT Location, Camp_id FROM camp WHERE camp_id NOT IN (SELECT Camp_Id FROM ngo)";
$result2 = mysqli_query($conn,$sql1);



// we need to check if the input in the form textfields are not empty
if(isset($_POST['name']) && isset($_POST['email']) && isset($_POST['camp']) && isset($_POST['manager'])&& isset($_POST['pass'])){
	// write the query to check if this username and password exists in our database
	
	$a = $_POST['name'];
	$b = $_POST['email'];
	$c= $_POST['camp'];
	$m = $_POST['manager'];
	$pass= $_POST['pass'];

	//check if the name is unique or not
	$check = "SELECT NGO_name FROM ngo WHERE NGO_name = '$a' ";
	$checker = mysqli_query($conn, $check);

	if(mysqli_num_rows($checker)>0){
		echo "This NGO already manages a camp. please select another ngo for this camp.<br>Redirecting to sign up ....";
		header('Refresh:1; url=add_NGO.php');
		exit();
	}
	
	//
	$sql = "INSERT INTO ngo (NGO_name, Contact_Email, Camp_id, Operating_Areas,	Manager_name) VALUES ('$a','$b','$c','Syria','$m')";
	//Execute the query 
	$result = mysqli_query($conn, $sql);

	$sql= "INSERT INTO ngo_credential VALUES ('$a' , '$pass')";
	$passresult = mysqli_query($conn, $sql);
	
	//check if this insertion is happening in the database
	if($result && $passresult){
	
		echo "Registered Successfully. Redirecting to Sign in...";
		header('Refresh:1; url=add_NGO.php');
	}
	else{
		//echo "Insertion Failed";
		header("Location: add_NGO.php");
	}

}
?>




<html lang="en">
  <head>
      <meta charset="utf-8"/>
      <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
      <meta name="description" content="About the site"/>
      <meta name="author" content="Author name"/>
      <title> SAFR_NGO </title>
    
      <!-- core CSS -->
      <link href="../css/bootstrap.min.css" rel="stylesheet"/>
      <link href="../css/font-awesome.min.css" rel="stylesheet"/>
      <link href="../css/animate.min.css" rel="stylesheet"/>
      <link href="../css/main.css" rel="stylesheet"/> 
  </head>

  <body> 
    <!-- following section is used for creating the menubar in the webpage -->
	<section id="header">
		<div class="row">  
			<div class="col-md-2" style="font-size: 30px;color:#F2674A;"> SAFR </div>
			<div class="col-md-10" style="text-align: right"> 
				<a href="#"> return to selection </a> 
		
			</div>
		</div>
	</section>
	
	<section id = "section1">
		<div class="title"> NGO Sign_up  </div>
		
		<form action="add_NGO.php" class="form_design" method="post">
			
			Name: <input type="text" name="name" required> <br/> 
			Password: <input type="password" name="pass" required> <br/> 
			email: <input type="text" name="email" required> <br/>
			Camp:  <br><br>
				<select name="camp" required>
					<?php while($row = mysqli_fetch_assoc($result2)){ ?>
					<option value="<?php echo $row['Camp_id']; ?>">
						<?php echo $row['Location']."-".$row['Camp_id']; ?>
						 </option>
						  <?php  }?>
						  </select>
						  <br><br>
			Operationg Areas:  <input type="text" name="country" value="Syria" readonly> <br/>
			Manger Name: <input type="text" name="manager" required> <br/>
			
			<br/>
			<input type="submit" value="Add to Database">
		</form>
	</section>

	<section id = "sign up">
        <div class="title"> REGISTERED? SIGN IN</div>
        <a href="NGOsign.php">
            <input type="submit" value = "Sign In">
        </a>
    </section>

	
	<!----- Footer ----->
	<section id="footer"> 
	
	</section>
    <script src="../js/jquery.js"></script>
    <script src="../js/bootstrap.min.js"></script>
    <script src="../js/jquery.isotope.min.js"></script>
    <script src="../js/wow.min.js"></script>
  </body> 
</html>

