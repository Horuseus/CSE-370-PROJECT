<?php
    session_start();
    include('../dbconnect.php');
    
    $s = $_POST['skill'];
    $aid = $_POST['aid'];
    $campid = $_POST['cid'];
    $date = $_POST['date'];

    $sql = "SELECT Volunteer_id FROM volunteer WHERE skill='$s'";
    $result = mysqli_query($conn,$sql);
?>

<html lang="en">
  <head>
      <meta charset="utf-8"/>
      <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
      <title> SAFR_NGO </title>
      <link href="../css/bootstrap.min.css" rel="stylesheet"/>
      <link href="../css/font-awesome.min.css" rel="stylesheet"/>
      <link href="../css/animate.min.css" rel="stylesheet"/>
      <link href="../css/main.css" rel="stylesheet"/> 
  </head>
  <body>
    <section id="header">
        <div class="row">  
            <div class="col-md-2" style="font-size: 30px;color:#F2674A;"> SAFR </div>
            <div class="col-md-10" style="text-align: right"><a href="assignments.php"> View Assignments </a>
            <div class="col-md-10" style="text-align: right"><a href="add_assignment.php"> Create Assignment </a>
</div>
        </div>
    </section>

    <section id="section1">
        <div class="title"> Assign to a Volunteer </div>

        <form action="insert_assignment.php" method="post" class="form_design">
            Assignment ID: <input type="text" name="aid" value="<?php echo $aid ?>" readonly> <br/><br>
            Camp ID: <input type="text" name="cid" value="<?php echo $campid ?>" readonly> <br/><br>
            Date: <input type="text" name="date" value="<?php echo $date ?>" readonly> <br/><br>
            Skill: <input type="text" name="skill" value="<?php echo $s ?>" readonly> <br/><br>

            Volunteer:
            <select name="vid" required>
                <option value="" disabled selected>-- Select Volunteer --</option>
                <?php 
                    if(mysqli_num_rows($result) > 0){
                        while($row = mysqli_fetch_assoc($result)){
                            echo '<option value="' . $row['Volunteer_id'] . '">' . $row['Volunteer_id'] . '</option>';
                        }
                    } else {
                        echo '<option value="" disabled>No volunteers with this skill</option>';
                    }
                ?>
            </select>
            <br><br>
            <input type="submit" value="Create Assignment">
        </form>
    </section>

    <section id="footer"></section>
    <script src="../js/jquery.js"></script>
    <script src="../js/bootstrap.min.js"></script>
    <script src="../js/jquery.isotope.min.js"></script>
    <script src="../js/wow.min.js"></script>
  </body>
</html>