<?php
session_start();
include("../dbconnect.php");

if(!isset($_SESSION['safr_id'])){
   // header("Location: refugee_login.php");
    exit();
}

$safr_id = $_SESSION['safr_id'];

$sql= "SELECT * FROM evac_request WHERE Safr_id ='$safr_id' AND Status= 0 ";
$result = mysqli_query($conn,$sql);
if(mysqli_num_rows($result)>0){
    echo "Already submitted a Evacuation request request";

    header('Refresh:1; url=evac_list.php');
    //exit();
}

// auto generate evareq_id by counting rows + 1
$count_sql    = "SELECT * FROM evac_request";
$count_result = mysqli_query($conn, $count_sql);
$count   = mysqli_num_rows($count_result);
$next_num     = $count + 1;



$evareq_id = "EVAC0" . $next_num;

// todays date
$date = date("Y-m-d");

// if form is submitted
if(isset($_POST['priority']) && isset($_POST['location'])){
    $priority = $_POST['priority'];
    $location = $_POST['location'];

    $sql = "INSERT INTO evac_request (Evareq_id, Status, Priority, Request_date, Allocation_date, Safr_id, Operating_areas) 
            VALUES ('$evareq_id', 0, '$priority', '$date', NULL, '$safr_id', '$location')";
    mysqli_query($conn, $sql);

    if(mysqli_affected_rows($conn)){
        header('location: evac_list.php');
    }
    
}
?>

<html>
<head><title>Evacuation Request</title></head>
<body>
    <h2>Evacuation Request Form</h2>
    <a href="refugee_dashboard.php">Back to Dashboard</a>
    <br><br>
    <form action="evac_rec.php"method="post">
                <b>SAFR ID:</b>
                <input type = "text" value="<?php echo $safr_id; ?>" readonly>
                <br><br>
                
                <b>Request ID:</b>
                <input type="text" value="<?php echo $evareq_id; ?>"readonly>
                <br><br>

                <b>Request Date:</b>
                <input type="text" value="<?php echo $date ?>" readonly>
                <br><br>

                <b>Priority:</b>
                <select name="priority" required>
                    <option value="" disabled selected>-- Select Priority --</option>
                    <option value="Chronically Ill">Chronically Ill</option>
                    <option value="Minor">Minor</option>
                    <option value="Elder">Elder</option>
                    <option value="General">General</option>
                </select>
                <br><br>

            
                <b>Destination Location:</b>
                    <select name="location" required>
                        <option value="">-- Select Location --</option>
                        <option value="Aleppo">Aleppo</option>
                        <option value="Damascus">Damascus</option>
                        <option value="Homs">Homs</option>
                        <option value="Latakia">Latakia</option>
                        <option value="Daraa">Daraa</option>
                        <option value="Deir ez-Zor">Deir ez-Zor</option>
                        <option value="Raqqa">Raqqa</option>
                        <option value="Idlib">Idlib</option>
                        <option value="Hasakah">Hasakah</option>
                        <option value="Hama">Hama</option>
                        <option value="Tartus">Tartus</option>
                        <option value="Quneitra">Quneitra</option>
                        <option value="As-Suwayda">As-Suwayda</option>
                    </select> <br><br>
            
                <b>Status:</b>Pending (0) <br><br>


            
                <b>Allocation Date:</b>Will be assigned by NGO<br><br>
        <br>
        <input type="submit" value="Submit Evacuation Request">
    </form>
    <h3><a href="evac_list.php">Previous Requests</a></h3>
</body>
</html>