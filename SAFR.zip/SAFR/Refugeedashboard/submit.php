<?php
session_start();
include("../dbconnect.php");

if(!isset($_SESSION['safr_id'])){
    header("Location: ../refugee login/login.php");
    exit;
}

$safr_id = $_SESSION['safr_id'];

$sql= "SELECT * FROM search_req WHERE Safr_id ='$safr_id'";
$result = mysqli_query($conn,$sql);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My search</title>
</head>
<body>
    <div align="center">
    <h2>My Search Request</h2>

    <table border="1" cellpadding="10" cellspacing="0">
        <tr>
            <th>Missing Name</th>
            <th>Document Number</th>
            <th>Status</th>
            <th>Matched SAFR ID</th>
        </tr>

        <?php
        if(mysqli_num_rows($result) > 0){
            while($row = mysqli_fetch_assoc($result)){
                echo "<tr>";
                
                echo "<td>" . $row['Missing_Name'] . "</td>";
                echo "<td>" . $row['Doc_number'] . "</td>";

                if($row['Status'] == 0){
                    echo "<td>Pending</td>";
                    echo "<td>Not Found</td>";
                } else {
                    echo "<td>Found</td>";
                    echo "<td>" . $row['Match_Safr_id'] . "</td>";
                }

                
            }
        } 
        else {
           echo "NO search request were submitted"; 
        }
        ?>

    </table>

    <br><br>

    <a href="family_Search.php">New Search Request</a> |
    <a href="refugee_dashboard.php">Back to Dashboard</a> |
    <a href="live_search.php">Live Search</a>

</div>
</body>
</html>

