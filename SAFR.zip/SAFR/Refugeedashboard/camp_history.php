<?php
session_start();
include("../dbconnect.php");

if(!isset($_SESSION['safr_id'])){
    header("Location: refugee_login.php");
    exit;
}

$safr_id = $_SESSION['safr_id'];

$sql    = "SELECT r.Camp_id, r.Arrival_date, r.Departure_date, c.Location
            FROM refugee_stay_in_camp r
            JOIN camp c
            ON r.Camp_id=c.Camp_id
            WHERE r.Safr_id= '$safr_id'
            ORDER BY r.Departure_date ASC";
$result = mysqli_query($conn, $sql);
?>

<html>
<head><title>Camp History</title></head>
<body>
    <h2>My Camp History</h2>
    <hr>

    <table  cellpadding="10" style="margin: auto;">
        <tr>
            <th>Location</th>
            <th>Camp ID</th>
            <th>Arrival Date</th>
            <th>Departure Date</th>
        </tr>

        <?php
        if(mysqli_num_rows($result) > 0){
            while($row = mysqli_fetch_array($result)){
                echo "<tr>";
                echo "<td>" . $row['Location'] . "</td>";
                echo "<td>" . $row['Camp_id'] . "</td>";
                echo "<td>" . $row['Arrival_date'] . "</td>";
                echo "<td>" . ($row['Departure_date'] ? $row['Departure_date'] : 'Currently here') . "</td>";
                echo "</tr>";
            }
        }
        ?>
    </table>

    <br>
    <div style="text-align: center;">
        <a href="camp_change.php" style="margin-right: 30px; font-size:20px">Change camps</a>
        <a href="refugee_dashboard.php" style="font-size:20px">Back to Dashboard</a>
    </div>
</body>
</html>