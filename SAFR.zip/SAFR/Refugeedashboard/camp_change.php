<?php
session_start();
include("../dbconnect.php");

if(!isset($_SESSION['safr_id'])){
    header("Location: refugee_login.php");
    exit;
}

$safr_id = $_SESSION['safr_id'];
//current camp_id
$sql= "SELECT * FROM refugee_stay_in_camp WHERE Safr_id = '$safr_id' ORDER BY Arrival_date DESC LIMIT 1";
$cid_result = mysqli_query($conn, $sql);
$camp_id2 = mysqli_fetch_array($cid_result);
$camp_id= $camp_id2['Camp_id'];
//current camp_name
$sql = "SELECT * FROM camp WHERE Camp_id='$camp_id'" ;
$cname_result= mysqli_query($conn,$sql);
$c_name=mysqli_fetch_array($cname_result);
$camp_name = $c_name['Location'];

//to get the camps except the camp he is in
$sql =" SELECT Camp_id, Location FROM camp WHERE Camp_id != '$camp_id'";
$camps= mysqli_query($conn,$sql);

//to check for submit
if(isset($_POST['destination']) && isset($_POST['dept_date'])){
    $d = $_POST['destination'];
    $c = $_POST['dept_date'];
    $a =  date("Y-m-d", strtotime($c . " +2 days"));

    //to set the departure date
    $sql = "UPDATE  refugee_stay_in_camp SET Departure_date = '$c' 
                        WHERE Safr_id = '$safr_id' AND Camp_id= '$camp_id'";
    $result = mysqli_query($conn,$sql);

    //to set the arrival date in the new camp
    $sql = "INSERT INTO refugee_stay_in_camp (Safr_id, Camp_id, Arrival_date, Departure_date)
                         VALUES ('$safr_id','$d','$a',NULL)";
    $result2 = mysqli_query($conn,$sql);

    if(mysqli_affected_rows($conn)){
        header('Location: refugee_dashboard.php');
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Camp Change</title>
</head>
<body>
     <section id="header">
        <div class="row">
            <div class="col-md-2" style="font-size: 30px; color:#F2674A;"> <a href="refugee_dashboard.php" style="color:#F2674A";>SAFR </a> </div>
            <div class="col-md-8"></div>
            <div class="col-md-2" style="text-align: right">
                <a href="camp_history.php" style="font-size: 20px"> CAMP History </a> |
                <a href="refugee_dashboard.php"> Dashboard </a> | 
                <a href="refugee_logout.php"> Logout </a>
            </div>
        </div>
    </section>

    <section id="section1">
        <div class="title" style="font-size:30px;text-align:justify"> Update My Destination </div>

        <div style="margin-left:20%; margin-right:20%; margin-top:50px;font-size:30px">
            <p><b>Current Camp:</b> <?php echo $camp_name; ?></p>

            <form action="camp_change.php" method="post">
                <label>Next Destination:</label><br>
                <?php 
                    if(mysqli_num_rows($camps)>0){
                        while($row = mysqli_fetch_array($camps)){
                             echo '<input type="radio" name="destination" value="' . $row['Camp_id'] . '"> ';
                             echo $row['Location'] . ' - ' . $row['Camp_id'];
                             echo '<br>';
                        }
                    }
                ?>

                <h3>Departure Date:</h3>
                <input type="date" name="dept_date" required><br><br>
                <input type="submit" value="departure_date">
            </form>
        </div>

</body>
</html>