<?php
session_start();
include("../dbconnect.php");

if(!isset($_SESSION['safr_id'])){
    header("Location: refugee_login.php");
    exit;
}

$safr_id = $_SESSION['safr_id'];

// if form is submitted add the new document
if(isset($_POST['doc_number']) && isset($_POST['doc_name'])){
    $doc_number = $_POST['doc_number'];
    $doc_type   = $_POST['doc_name'];

    $sql = "INSERT INTO identity_doc (Safr_id, Doc_number, Doc_type) 
            VALUES ('$safr_id', '$doc_number', '$doc_type')";
    mysqli_query($conn, $sql);
}

// get all documents for this refugee
$sql    = "SELECT * FROM identity_doc WHERE Safr_id = '$safr_id'";
$result = mysqli_query($conn, $sql);
?>

<html>
<head><title>My Documents</title></head>
<body>
    <h2>My Identity Documents</h2>
    <a href="refugee_dashboard.php">Back to Dashboard</a>
    <hr>

    <!-- show existing documents -->
    <h3>My Documents</h3>
    <table border="1" cellpadding="10" style="margin:auto;">
        <tr>
            <th>Document Type</th>
            <th>Document Number</th>
        </tr>

        <?php
        if(mysqli_num_rows($result) > 0){
            while($row = mysqli_fetch_array($result)){
                echo "<tr>";
                echo "<td>" . $row['Doc_type'] . "</td>";
                echo "<td>" . $row['Doc_number'] . "</td>";
                echo "</tr>";
            }
        }
        ?>
    </table>

    <hr>
    
    <h3>Add New Document</h3>
    <form method="post">

        Document Type: <br>
        <select name="doc_name" required>
            <option value="">-- Select Document Type --</option>
            <option value="NID">NID</option>
            <option value="Passport">Passport</option>
            <option value="Driving License">Driving License</option>
            <option value="School/Office ID Card">School/Office ID Card</option>
        </select>
        <br><br>

        Document Number: <br>
        <input type="text" name="doc_number" placeholder="Enter document number" required><br><br>

        <input type="submit" value="Add Document">
    </form>

    <br>
</body>
</html>