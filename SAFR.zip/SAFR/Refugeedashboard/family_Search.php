<?php
    session_start();
include("../dbconnect.php");

if(!isset($_SESSION['safr_id'])){
    header("Location: ../refugee login/login.php");
    exit;
}

$safr_id = $_SESSION['safr_id'];

if(isset($_POST['missing_name']) && isset($_POST['doc_number']) && isset($_POST['Doc_name'])){
    $u =$_POST['missing_name'];
    $doc_type = $_POST['Doc_name'];
    $n =$doc_type."-".$_POST['doc_number'];
    if(empty($n)){
        $n = NULL;
    }


    $sql = "INSERT INTO search_req (Safr_id , Status, Missing_Name,Doc_number,Match_Safr_id)
                                VALUES ('$safr_id','0','$u','$n',NULL)";
    $result = mysqli_query($conn,$sql);
    if(mysqli_affected_rows($conn)>0){
       header('location:submit.php');
    }
}
?>

<html>
<head><title>Family Search</title></head>
<body>
    <h2>Search for a Family Member</h2>
    <a href="refugee_dashboard.php">Back to Dashboard</a>
    <hr>

    <form action="" method="post">

        <b>Your SAFR ID:</b><br>
        <input type="text" value="<?php echo $safr_id; ?>" readonly>
        <br><br>

        <b>Missing Person's Full Name:</b><br>
        <input type="text" name="missing_name" placeholder="Enter full name of missing person" required>
        <br><br>

        <b>Missing Person's Document Type & Number:</b><br>

        <select  required name='Doc_name'>
            <option value="">-- Select Document Type --</option>
            <option value="DIFF">None of the mentioned</option>
            <option value="NID">NID</option>
            <option value="PID">Passport</option>
            <option value="DL">Driving License</option>
            <option value="EDU">School/Office ID Card</option>
        </select>

        <input type="text" name="doc_number" placeholder="Enter their passport or ID number" required>
        <br><br>

        <b>Status:</b> Pending (will be updated when found)
        <br><br>

        <input type="submit" value="Submit Search Request">
    </form>

    <br>
    <a href="submit.php">My Request</a><br><br>
    <h3><a href="refugee_dashboard.php">Back to Dashboard</a></h3>
</body>
</html>