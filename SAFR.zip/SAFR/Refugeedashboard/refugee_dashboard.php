<?php
session_start();
include("../dbconnect.php");

if(!isset($_SESSION['safr_id'])){
    header("Location: ../refugee login/login.php");
    exit;
}

$safr_id = $_SESSION['safr_id'];

$sql    = "SELECT * FROM refugee WHERE Safr_id = '$safr_id'";
$result = mysqli_query($conn, $sql);
$refugee = mysqli_fetch_array($result);

$sql= "SELECT * FROM refugee_stay_in_camp WHERE Safr_id = '$safr_id' ORDER BY Arrival_date DESC LIMIT 1";
$cid_result = mysqli_query($conn, $sql);
$camp_id2 = mysqli_fetch_array($cid_result);
$camp_id= $camp_id2['Camp_id'];

$sql = "SELECT * FROM camp WHERE Camp_id='$camp_id'" ;
$cname_result= mysqli_query($conn,$sql);
$c_name=mysqli_fetch_array($cname_result);
$camp_name = $c_name['Location'];


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DASHBOARD</title>
</head>
<body>
    <body> 
    <!-- following section is used for creating the menubar in the webpage -->
	<section id="header">
		<div class="row">  
			<div class="col-md-2" style="font-size: 20px;color:#F2674A;">SAFR </div>
			<div class="col-md-2" style="font-size: 30px;color:#F2674A;"> 
				<?php	echo "Hello, {$refugee['Full_name']}"; ?>
				<a href="refugee_logout.php" style="position: absolute; right: 30px; top: 10px; font-size: 25px; color:red;">Logout</a>
			</div>
			<div class="col-md-10" style="text-align: center;font-size: 25px;"> 
				<a href="see_documents.php"> See Added Documents</a> 
				<a href="family_search.php" style="margin-left: 25px;"> Family Search </a> 
				<a href="evac_rec.php" style="margin-left: 25px;"> Evacuation Request</a>
				<a href="camp_change.php" style="margin-left: 25px;"> Camp change</a>
			</div>
			
		</div>
	</section>
	
	<section id = "section1">
		<div class="title"> </div>
		<div style="border: 2px solid #5bbda9; padding: 10px; width: 30%; margin: 200px auto;">
			<h2 style="text-align: center;"> <?php	echo "{$refugee['Full_name']}'s Information"; ?></h2>
			<h3 style="text-align: center;"> <?php	echo "SAFR ID: {$refugee['Safr_id']}"; ?></h3>
			<h4 style="margin-left: 30px;"> <?php	echo "Date of Birth: {$refugee['Date_of_Birth']}"; ?></h4>
			<h4 style="margin-left: 30px;"> <?php	echo "Blood Group: {$refugee['Blood_Group']}"; ?></h4>
			<h4 style="margin-left: 30px;"> <?php	echo "City: {$refugee['City']}"; ?></h4>
			<h4 style="margin-left: 30px;"> <?php	echo "Current Camp Location: {$camp_name}"; ?></h4>
		</div>
	</section>

	
	<!----- Footer ----->
	<section id="footer"> 
	
	</section>
    <script src="js/jquery.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.isotope.min.js"></script>
    <script src="js/wow.min.js"></script>
  </body> 
</body>
</html>