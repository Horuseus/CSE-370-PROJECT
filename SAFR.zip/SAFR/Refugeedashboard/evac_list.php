<?php
session_start();
include("../dbconnect.php");

if(!isset($_SESSION['safr_id'])){
    header("Location: refugee_login.php");
    exit;
}

$safr_id = $_SESSION['safr_id'];

$sql = "SELECT * FROM evac_request WHERE Safr_id = '$safr_id' ";
$result= mysqli_query($conn,$sql);

if(mysqli_num_rows($result)==0){
    header('location:evac_rec.php');
    //exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Previous Requests</title>
</head>
<body>
    <h2 style="text-align:center;">Your Evacuation Requests</h2>

<div style="width:80%; margin: 20px auto;">
    <table border="1" cellpadding="10" cellspacing="0" width="100%">
        <tr>
            <th>Request ID</th>
            <th>Priority</th>
            <th>Location</th>
            <th>Request Date</th>
            <th>Approval Date</th>
            <th>Status</th>
        </tr>

        <?php while($row = mysqli_fetch_assoc($result)) { ?>
            <tr>
                <td><?php echo $row['Evareq_id']; ?></td>
                <td><?php echo $row['Priority']; ?></td>
                <td><?php echo $row['Operating_areas']; ?></td>
                <td><?php echo $row['Request_date']; ?></td>
                <td><?php echo $row['Allocation_date']; ?></td>
                <td>
                    <?php 
                        if($row['Status'] == 0){
                            echo "Pending";
                        } else {
                            echo "Approved";
                        }
                    ?>
                </td>
            </tr>
        <?php } ?>

    </table>
</div>

<div style="text-align:center;">
    <a href="evac_rec.php">Make New Request</a> |
    <a href="refugee_dashboard.php">Back to Dashboard</a>
</div>
</body>
</html>