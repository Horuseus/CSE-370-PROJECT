<?php
    include("../dbconnect.php");
    $safr_id = $_GET['safr_id'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Set Up your password</title>
</head>
<body>
    <h3>SAVE THIS ID: <?php echo $safr_id ?></h3>
    <form action="save_pass.php"  method="post">
            <input type="hidden" name="safr_id" value="<?php echo $safr_id; ?>"><br>
			Password: <br><input type="password" name="pass" required><br/> 	
            <input type="submit" value="confirm">	
    </form>

</body>
</html>
<?php 
    mysqli_close($conn);
 ?>
