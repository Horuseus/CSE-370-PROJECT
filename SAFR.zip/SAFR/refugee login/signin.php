<?php
	session_start();
    require_once("../dbconnect.php");


    if(isset($_POST['Sid']) && isset($_POST['pass'])){
	$u = $_POST['Sid'];
	$p = $_POST['pass'];

    if(empty($u)){
            echo "please enter an username";
        }
    else if(empty($p)){
            echo "please enter password";
        }
    else{
	$sql = "SELECT * FROM refugee_credential WHERE Safr_id  = '$u' AND Password = '$p'";
	
	//Execute the query 
	$result = mysqli_query($conn, $sql);
	
	//check if it returns an empty set
	if(mysqli_num_rows($result) !=0 ){
		$_SESSION['safr_id']=$u;
		//echo "LET HIM ENTER";
		header("Location: ../Refugeedashboard/refugee_dashboard.php");
	}
	else{
		header("Location: login.php");
        echo "Username or Password is wrong";
	}
	}
}
?>