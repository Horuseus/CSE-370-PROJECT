<html lang="en">
  <head>
      <meta charset="utf-8"/>
      <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
      <meta name="description" content="About the site"/>
      <meta name="author" content="Author name"/>
      <title> LOG-IN REFUGEE </title>
    
      <!-- core CSS -->
      <link href="css/bootstrap.min.css" rel="stylesheet"/>
      <link href="css/font-awesome.min.css" rel="stylesheet"/>
      <link href="css/animate.min.css" rel="stylesheet"/>
      <link href="css/main.css" rel="stylesheet"/> 
  </head>

  <body> 
    <!-- following section is used for creating the menubar in the webpage -->
	
	<section id = "section1">
		<div class="title"> SIGN IN </div>
		<br>
		<form action="signin.php" class="form_design" method="post">
			SAFR ID:<br> <input type="text" name="Sid" required> <br/>
			Password: <br><input type="password" name="pass" required> <br/> <br/>
	 		<input type="submit" value="Sign In">
		</form>
	</section>
     
    <!-- sign up -->

	<section id = "sign up">
        Not Registered?
        <a href="add_refugee.php">
            <button type="button">Sign_UP</button>
        </a>
    </section>


	<!----- Footer ----->
	<section id="footer"> 
	
	</section>
    <script src="js/jquery.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.isotope.min.js"></script>
    <script src="js/wow.min.js"></script>
  </body> 
</html>

