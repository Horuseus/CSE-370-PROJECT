<html lang="en">
  <head>
      <meta charset="utf-8"/>
      <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
      <meta name="description" content="About the site"/>
      <meta name="author" content="Author name"/>
      <title> Welcome to official SAFR </title>
    
      <!-- core CSS -->
      <link href="css/bootstrap.min.css" rel="stylesheet"/>
      <link href="css/font-awesome.min.css" rel="stylesheet"/>
      <link href="css/animate.min.css" rel="stylesheet"/>
      <link href="css/main.css" rel="stylesheet"/> 
  </head>

  <body> 
    <!-- following section is used for creating the menubar in the webpage -->
	<section id="header">
		<div class="row">  
			<div class="col-md-2" style="font-size: 30px;color:#F2674A;"> SAFR </div>
			<div class="col-md-10" style="text-align: right">
				<!--<a href="NGO/NGOsign.php" style="margin-left: 20px;"> NGO </a> 
				<a href="Volunteer/Volunteer_signin.php" style="margin-left: 20px;"> volunteer  </a> -->
			</div>
		</div>
	</section>
	
	<section id = "section1">
		<div class="title"> SELECT ROLE </div><br><br>
		<div class="col-md-20" style="text-align: center; font-size:large">
				<a href="donor FILES/donor.php"> DONOR </a> 
				<a href="refugee login/login.php" style="margin-left: 40px;"> Refugee </a> 
				<a href="NGO/NGOsign.php" style="margin-left: 40px;"> NGO </a> 
				<a href="Volunteer/Volunteer_signin.php" style="margin-left: 40px;"> VOLUNTEER  </a> 
			</div>
		
	</section>

	
	<!----- Footer ----->
	<section id="footer"> 
	
	</section>
    <script src="js/jquery.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.isotope.min.js"></script>
    <script src="js/wow.min.js"></script>
  </body> 
</html>

