<?php
    session_start();
    include('../dbconnect.php');
    $vol_id = $_SESSION['vol_id'];

    $sql = "SELECT Assignment_ID FROM assignment WHERE Volunteer_id = '$vol_id'";
    $result = mysqli_query($conn, $sql); // separate variable

    if(isset($_POST['assign']) && isset($_POST['outcome'])){
        $u = $_POST['assign'];
        $o = $_POST['outcome'];

        $sql2 = "INSERT INTO volunteers_quota VALUES ('$vol_id','$o','$u')";
        $result2 = mysqli_query($conn, $sql2);

        if(mysqli_affected_rows($conn)){
            header('location:assigned_ass.php');
        }
    }
?>

<html lang="en">
  <head>
      <meta charset="utf-8"/>
      <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
      <meta name="description" content="About the site"/>
      <meta name="author" content="Author name"/>
      <title> THE TITLE </title>
    
      <!-- core CSS -->
      <link href="../css/bootstrap.min.css" rel="stylesheet"/>
      <link href="../css/font-awesome.min.css" rel="stylesheet"/>
      <link href="../css/animate.min.css" rel="stylesheet"/>
      <link href="../css/main.css" rel="stylesheet"/> 
  </head>

  <body> 
    <!-- following section is used for creating the menubar in the webpage -->
	<section id="header">
		<div class="row">  
			<div class="col-md-2" style="font-size: 30px;color:#F2674A;"> SAFR </div>
		</div>
	</section>
	
	<section id = "section1">
		<div class="title"> Outcome </div>
		</section>
	<form action="Outcome.php" method= "post">
      <label>Select ASSIGNMENT</label><br>
        <select name="assign" required>
            <option value="" disabled selected>-- Select Assignment --</option>
            <?php while($row = mysqli_fetch_assoc($result)){ ?>
                <option value="<?php echo $row['Assignment_ID']; ?>">
                    <?php echo $row['Assignment_ID']; ?>
                </option>
            <?php } ?>
        </select>
        <br><br>
	    <label>whats your opinion</label><br>
		<input type="text" name = "outcome" required><br>
		<input type="submit" name = "submit"><br>
	</form>
		
		<section id = "section2">
		<div class="title"> thank you for sharing  </div>
		</section>
		
		
		
	

	
	<!----- Footer ----->
	<section id="footer"> 
	
	</section>
    <script src="../js/jquery.js"></script>
    <script src="../js/bootstrap.min.js"></script>
    <script src="../js/jquery.isotope.min.js"></script>
    <script src="../js/wow.min.js"></script>
  </body> 
</html>