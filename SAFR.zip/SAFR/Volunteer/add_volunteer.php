<?php
	include('../dbconnect.php');

	$sql = "SELECT * FROM `volunteer` ORDER BY `volunteer`.`Volunteer_id` DESC LIMIT 1";
	$result = mysqli_query($conn,$sql);
	$row = mysqli_fetch_assoc($result);
	$lastID = $row['Volunteer_id'];
	$num = filter_var($lastID, FILTER_SANITIZE_NUMBER_INT) + 1;
	$volid= "VOL0".$num;
?>

<html lang="en">
  <head>
      <meta charset="utf-8"/>
      <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
      <meta name="description" content="About the site"/>
      <meta name="author" content="Author name"/>
      <title> SAFR_Volunteer </title>
    
      <!-- core CSS -->
      <link href="../css/bootstrap.min.css" rel="stylesheet"/>
      <link href="../css/font-awesome.min.css" rel="stylesheet"/>
      <link href="../css/animate.min.css" rel="stylesheet"/>
      <link href="../css/main.css" rel="stylesheet"/> 
  </head>

  <body> 
    <!-- following section is used for creating the menubar in the webpage -->
	<section id="header">
		<div class="row">  
			<div class="col-md-2" style="font-size: 30px;color:#F2674A;"> SAFR </div>
			<div class="col-md-10" style="text-align: right"> 
				<a href="Volunteer_signin.php"> return to Sign In </a> 
		
			</div>
		</div>
	</section>
	
	<section id = "section1">
		<div class="title"> Be volunteer  </div>
		
		<form action="insert_volunteer.php" class="form_design" method="post">
			Vol ID: <input type="text" name="vid" value="<?php echo $volid; ?>" required readonly> <br/>
			Name: <input type="text" name="sname" required> <br/> 
			Password: <input type="password" name="pass" required> <br/>
			email: <input type="text" name="email" required> <br/>
			phone: <input type="text" name="phn" required> <br/>
			home country: <input type="text" name="origin" required> <br/>
			Skill: <br> <br>
				<select name="skill" required>
					<option value="" disabled selected>-- Select a Skill --</option>
					<option value="Education">Education</option>
					<option value="Distribution">Distribution</option>
					<option value="Counselling">Counselling</option>
					<option value="Mechanic">Mechanic</option>
					<option value="Logistics">Logistics</option>
					<option value="Translation">Translation</option>
					<option value="Medical Worker">Medical Worker</option>
				</select>
				<br><br>
			
			<br/>
			<input type="submit" value="Register">
		</form>
	</section>

	
	<!----- Footer ----->
	<section id="footer"> 
	
	</section>
    <script src="../js/jquery.js"></script>
    <script src="../js/bootstrap.min.js"></script>
    <script src="../js/jquery.isotope.min.js"></script>
    <script src="../js/wow.min.js"></script>
  </body> 
</html>

