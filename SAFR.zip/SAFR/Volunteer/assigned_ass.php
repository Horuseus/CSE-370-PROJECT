<?php
    session_start();
    include('../dbconnect.php');
    $vol_id = $_SESSION['vol_id'];

    $sql = "SELECT Assignment_ID, Assigned_Date, Camp_id FROM assignment WHERE Volunteer_id = '$vol_id'";
    $result = mysqli_query($conn, $sql);
?>

<html lang="en">
  <head>
      <meta charset="utf-8"/>
      <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
      <title> SAFR_Volunteer </title>
      <link href="../css/bootstrap.min.css" rel="stylesheet"/>
      <link href="../css/font-awesome.min.css" rel="stylesheet"/>
      <link href="../css/animate.min.css" rel="stylesheet"/>
      <link href="../css/main.css" rel="stylesheet"/> 
  </head>
  <body>
    <section id="header">
        <div class="row">  
            <div class="col-md-2" style="font-size: 30px;color:#F2674A;"> SAFR </div>
            <div class="col-md-10" style="text-align: right"> 
				<a href="Outcome.php" style="margin-left: 20px;"> record Outcome </a>
				<a href="../logout.php" style="margin-left: 20px;"> logout </a>
			</div>
        </div>
    </section>

    <section id="section1">
        <div class="title"> My Assignments </div>
        <div style="margin-left:10%; margin-right:10%; margin-top:50px; margin-bottom:50px;text-align:center;background:#66b3ff;">
            
            <div class="row" style="padding:5px; font-weight:bold;">
                <div class="col-md-4"> Assignment ID </div>
                <div class="col-md-4"> Assigned Date </div>
                <div class="col-md-4"> Camp ID </div>
            </div>

            <?php
            if(mysqli_num_rows($result) > 0){
                while($row = mysqli_fetch_assoc($result)){
            ?>
            <div class="row" style="padding:5px;">
                <div class="col-md-4"> <?php echo $row['Assignment_ID']; ?> </div>
                <div class="col-md-4"> <?php echo $row['Assigned_Date']; ?> </div>
                <div class="col-md-4"> <?php echo $row['Camp_id']; ?> </div>
            </div>
            <?php
                }
            } else {
                echo "<p>No assignments found</p>";
            }
            ?>

        </div>
    </section>

    <section id="footer"></section>
    <script src="../js/jquery.js"></script>
    <script src="../js/bootstrap.min.js"></script>
    <script src="../js/jquery.isotope.min.js"></script>
    <script src="../js/wow.min.js"></script>
  </body>
</html>